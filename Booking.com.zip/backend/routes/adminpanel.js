const express = require('express');
const router = express.Router();
const Hotel = require('../models/adminpanel');

const MAX_GALLERY_IMAGES = Hotel.MAX_GALLERY_IMAGES || 10;
const MAX_VIDEOS = Hotel.MAX_VIDEOS || 2;

/* GET /api/hotels  -> list all admin-added hotels (newest first) */
router.get('/', async (req, res) => {
  try {
    const hotels = await Hotel.find().sort({ createdAt: -1 });
    res.json({ success: true, count: hotels.length, hotels });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to fetch hotels', error: err.message });
  }
});

/* GET /api/hotels/:id  -> single hotel by slug id */
router.get('/:id', async (req, res) => {
  try {
    const hotel = await Hotel.findOne({ id: req.params.id });
    if (!hotel) return res.status(404).json({ success: false, message: 'Hotel not found' });
    res.json({ success: true, hotel });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to fetch hotel', error: err.message });
  }
});

/* POST /api/hotels/add  -> create a new hotel from the admin panel form */
router.post('/add', async (req, res) => {
  try {
    const payload = req.body;

    const required = ['name', 'area', 'address', 'desc', 'price', 'image'];
    const missing = required.filter((f) => !payload[f]);
    if (missing.length) {
      return res.status(400).json({
        success: false,
        message: `Missing required fields: ${missing.join(', ')}`,
      });
    }

    if (Array.isArray(payload.gallery) && payload.gallery.length > MAX_GALLERY_IMAGES) {
      return res.status(400).json({
        success: false,
        message: `You can add at most ${MAX_GALLERY_IMAGES} gallery photos`,
      });
    }

    if (Array.isArray(payload.videos) && payload.videos.length > MAX_VIDEOS) {
      return res.status(400).json({
        success: false,
        message: `You can add at most ${MAX_VIDEOS} videos`,
      });
    }

    const hotel = new Hotel(payload);
    await hotel.save();
    res.status(201).json({ success: true, message: 'Hotel added successfully', hotel });
  } catch (err) {
    if (err.code === 11000) {
      return res.status(409).json({ success: false, message: 'A hotel with this ID already exists' });
    }
    res.status(500).json({ success: false, message: 'Failed to add hotel', error: err.message });
  }
});

/* PUT /api/hotels/:id  -> update an existing hotel */
router.put('/:id', async (req, res) => {
  try {
    if (Array.isArray(req.body.gallery) && req.body.gallery.length > MAX_GALLERY_IMAGES) {
      return res.status(400).json({
        success: false,
        message: `You can add at most ${MAX_GALLERY_IMAGES} gallery photos`,
      });
    }

    if (Array.isArray(req.body.videos) && req.body.videos.length > MAX_VIDEOS) {
      return res.status(400).json({
        success: false,
        message: `You can add at most ${MAX_VIDEOS} videos`,
      });
    }

    const hotel = await Hotel.findOneAndUpdate({ id: req.params.id }, req.body, {
      new: true,
      runValidators: true,
    });
    if (!hotel) return res.status(404).json({ success: false, message: 'Hotel not found' });
    res.json({ success: true, message: 'Hotel updated successfully', hotel });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to update hotel', error: err.message });
  }
});

/* DELETE /api/hotels/:id  -> remove a hotel */
router.delete('/:id', async (req, res) => {
  try {
    const hotel = await Hotel.findOneAndDelete({ id: req.params.id });
    if (!hotel) return res.status(404).json({ success: false, message: 'Hotel not found' });
    res.json({ success: true, message: 'Hotel deleted successfully' });
  } catch (err) {
    res.status(500).json({ success: false, message: 'Failed to delete hotel', error: err.message });
  }
});

module.exports = router;