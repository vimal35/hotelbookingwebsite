require('dotenv').config();

const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');

const hotelRoutes = require('./routes/adminpanel');

const app = express();

// Middleware
app.use(cors());

app.use(express.json({ limit: '5mb' }));
app.use(express.urlencoded({ extended: true, limit: '5mb' }));

// Routes
app.use('/api/hotels', hotelRoutes);

// Test route
app.get('/', (req, res) => {
  res.send('TravelNest Admin API is running');
});

// Server configuration
const PORT = process.env.PORT || 5000;

const MONGO_URI =
  process.env.MONGO_URI ||
  'mongodb://127.0.0.1:27017/travelnest';

// MongoDB connection
mongoose
  .connect(MONGO_URI)
  .then(() => {
    console.log('✅ MongoDB connected');

    app.listen(PORT, () => {
      console.log(`🚀 Server running on http://localhost:${PORT}`);
    });
  })
  .catch((err) => {
    console.error('❌ MongoDB connection failed:', err.message);
    process.exit(1);
  });