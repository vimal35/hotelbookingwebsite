const mongoose = require('mongoose');

/* ---------------------------- media limits ---------------------------- */

const MAX_GALLERY_IMAGES = 10;
const MAX_VIDEOS = 2;

/* ---------------------------- sub-schemas ---------------------------- */

const roomSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    bed: { type: String, required: true, trim: true },
    guests: { type: Number, required: true, default: 2, min: 1 },
    size: { type: Number, required: true, default: 30, min: 1 },
    price: { type: Number, required: true, min: 0 },
    img: { type: String, default: '' },
    benefits: [{ type: String, trim: true }],
  },
  { _id: false }
);

const landmarkSchema = new mongoose.Schema(
  {
    name: { type: String, required: true, trim: true },
    d: { type: String, required: true, trim: true }, // distance label e.g. "1.2 km"
  },
  { _id: false }
);

const reviewSchema = new mongoose.Schema(
  {
    name: { type: String, trim: true },
    country: { type: String, trim: true },
    date: { type: String, trim: true },
    score: { type: Number, min: 0, max: 10 },
    title: { type: String, trim: true },
    comment: { type: String, trim: true },
  },
  { _id: false }
);

const catsSchema = new mongoose.Schema(
  {
    Cleanliness: Number,
    Comfort: Number,
    Location: Number,
    Facilities: Number,
    Staff: Number,
    'Value for money': Number,
    'Free WiFi': Number,
  },
  { _id: false }
);

/* ------------------------------ main schema --------------------------- */

const hotelSchema = new mongoose.Schema(
  {
    id: { type: String, unique: true, index: true }, // url slug, auto-generated
    name: { type: String, required: true, trim: true },
    area: { type: String, required: true, trim: true },
    type: {
      type: String,
      enum: ['Hotel', 'Resort', 'Apartment', 'Villa', 'Hostel'],
      default: 'Hotel',
    },
    stars: { type: Number, min: 1, max: 5, default: 5 },
    rating: { type: Number, min: 0, max: 10, default: 8.5 },
    reviews: { type: Number, default: 0, min: 0 },

    price: { type: Number, required: true, min: 0 },
    oldPrice: { type: Number, default: null },
    taxes: { type: Number, default: 0, min: 0 },
    distance: { type: Number, default: 1, min: 0 },
    deal: { type: String, enum: ['limited', 'genius', 'new', null], default: null },

    breakfast: { type: Boolean, default: false },
    freeCancel: { type: Boolean, default: true },
    payLater: { type: Boolean, default: false },
    noPrepay: { type: Boolean, default: false },
    sustainable: { type: Boolean, default: false },

    address: { type: String, required: true, trim: true },
    checkIn: { type: String, default: '15:00 – 00:00' },
    checkOut: { type: String, default: '07:00 – 12:00' },
    desc: { type: String, required: true, trim: true },

    highlights: [{ type: String, trim: true }],
    amenities: [{ type: String, trim: true }],
    landmarks: [landmarkSchema],

    // Cover / hero image shown on listing cards
    image: { type: String, required: true, trim: true },

    // Gallery photos — up to MAX_GALLERY_IMAGES, shown on the detail page
    gallery: {
      type: [{ type: String, trim: true }],
      default: [],
      validate: {
        validator: (arr) => Array.isArray(arr) && arr.length <= MAX_GALLERY_IMAGES,
        message: `A property can have at most ${MAX_GALLERY_IMAGES} gallery photos`,
      },
    },

    // Property videos — up to MAX_VIDEOS, direct file links or streaming URLs
    videos: {
      type: [{ type: String, trim: true }],
      default: [],
      validate: {
        validator: (arr) => Array.isArray(arr) && arr.length <= MAX_VIDEOS,
        message: `A property can have at most ${MAX_VIDEOS} videos`,
      },
    },

    rooms: [roomSchema],
    guestReviews: [reviewSchema],
    cats: catsSchema,

    mapX: { type: Number, default: () => 12 + Math.floor(Math.random() * 76) },
    mapY: { type: Number, default: () => 12 + Math.floor(Math.random() * 70) },

    source: { type: String, default: 'admin' }, // distinguishes admin-added hotels from static sample data
  },
  { timestamps: true }
);

function slugify(str) {
  return str
    .toLowerCase()
    .trim()
    .replace(/[^a-z0-9]+/g, '-')
    .replace(/(^-|-$)+/g, '');
}

hotelSchema.pre('validate', async function preValidate(next) {
  try {
    const Hotel = mongoose.models.Hotel || mongoose.model('Hotel');

    if (!this.id && this.name) {
      const base = slugify(this.name) || 'hotel';
      let candidate = base;
      let i = 1;
      // eslint-disable-next-line no-await-in-loop
      while (await Hotel.exists({ id: candidate })) {
        candidate = `${base}-${i++}`;
      }
      this.id = candidate;
    }

    if (!this.cats || Object.keys(this.cats.toObject ? this.cats.toObject() : this.cats).length === 0) {
      const r = this.rating || 8.5;
      const j = (v) => Math.max(5, Math.min(9.8, Math.round(v * 10) / 10));
      this.cats = {
        Cleanliness: j(r + 0.3),
        Comfort: j(r + 0.1),
        Location: j(r - 0.2),
        Facilities: j(r + 0.2),
        Staff: j(r + 0.4),
        'Value for money': j(r - 0.5),
        'Free WiFi': j(r + 0.2),
      };
    }

    if (this.gallery && this.gallery.length > MAX_GALLERY_IMAGES) {
      this.gallery = this.gallery.slice(0, MAX_GALLERY_IMAGES);
    }

    if (this.videos && this.videos.length > MAX_VIDEOS) {
      this.videos = this.videos.slice(0, MAX_VIDEOS);
    }

    next();
  } catch (err) {
    next(err);
  }
});

module.exports = mongoose.models.Hotel || mongoose.model('Hotel', hotelSchema);
module.exports.MAX_GALLERY_IMAGES = MAX_GALLERY_IMAGES;
module.exports.MAX_VIDEOS = MAX_VIDEOS;