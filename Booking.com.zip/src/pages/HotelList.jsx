import React, { useEffect, useMemo, useRef, useState } from 'react';
import { Link } from 'react-router-dom';
import {
  Search, MapPin, CalendarDays, Users, ChevronDown, ChevronRight, Heart, Star, X,
  SlidersHorizontal, Wifi, Waves, Car, Dumbbell, UtensilsCrossed, Coffee, Dog, Plane,
  Sparkles, Leaf, ArrowRight, ArrowUpDown, LayoutGrid, Map as MapIcon, Clock, Check,
  Banknote, ShieldCheck, BadgeCheck, Briefcase, Sun, Shirt, Zap, ChefHat, Wind,
  Droplets, Umbrella, Wine, Soup, BedDouble,
} from 'lucide-react';
import './HotelList.css';

/* Change this if your backend runs elsewhere, or set VITE_API_URL in your .env */
const API_BASE = import.meta.env.VITE_API_URL || 'http://localhost:5000';

/* ---------------------------------- images ---------------------------------- */

const IMG = (id) =>
  `https://images.pexels.com/photos/${id}/pexels-photo-${id}.jpeg?auto=compress&cs=tinysrgb&fit=crop&h=627&w=1200`;

const EXTERIORS = [2771935, 16094034, 3011575, 18435555, 29038821, 9119625, 37526152, 32457946, 12194454, 36488760].map(IMG);
const DUBAI = [35155692, 35155691, 15478194, 35155695, 35155690, 35155694, 35155693, 12238319, 17865606, 7974839].map(IMG);
const ROOMS = [6434592, 7745929, 7031731, 6394574, 7746082, 6434588, 6585602, 6394617, 6394651, 8089081].map(IMG);
const POOLS = [261101, 297985, 261108, 14024796, 14024957, 14024792, 261105, 261204, 29000013, 3011574].map(IMG);
const LOBBIES = [14011664, 26729563, 12387992, 7821349, 26729556, 6758531, 14036253, 8312027, 19689235, 14036246].map(IMG);

/* --------------------------------- constants -------------------------------- */

export const AMENITY_ICONS = {
  'Free WiFi': Wifi,
  'Swimming pool': Waves,
  'Spa & wellness centre': Sparkles,
  'Free parking': Car,
  'Fitness centre': Dumbbell,
  Restaurant: UtensilsCrossed,
  Bar: Wine,
  'Room service': Soup,
  'Airport shuttle': Plane,
  'Family rooms': Users,
  'Pet friendly': Dog,
  'Beachfront': Umbrella,
  '24-hour front desk': Clock,
  'Business centre': Briefcase,
  Terrace: Sun,
  Laundry: Shirt,
  'EV charging station': Zap,
  Kitchenette: ChefHat,
  'Private pool': Waves,
  'Non-smoking rooms': Wind,
  'Water park access': Droplets,
  'Air conditioning': Wind,
  'Shared lounge': Users,
  Garden: Leaf,
};

const POPULAR_FILTERS = [
  { key: 'Free cancellation', icon: ShieldCheck },
  { key: 'Breakfast included', icon: Coffee },
  { key: 'No prepayment', icon: Banknote },
  { key: 'Swimming pool', icon: Waves },
  { key: 'Spa & wellness centre', icon: Sparkles },
  { key: 'Free parking', icon: Car },
  { key: 'Airport shuttle', icon: Plane },
  { key: 'Fitness centre', icon: Dumbbell },
  { key: 'Beachfront', icon: Umbrella },
  { key: 'Pet friendly', icon: Dog },
  { key: 'Family rooms', icon: Users },
  { key: 'Water park access', icon: Droplets },
  { key: 'Newly opened', icon: BadgeCheck },
];

const PROPERTY_TYPES = ['Hotel', 'Resort', 'Apartment', 'Villa', 'Hostel'];

const RATING_OPTS = [
  { v: 9, label: 'Exceptional 9+' },
  { v: 8, label: 'Excellent 8+' },
  { v: 7, label: 'Very good 7+' },
  { v: 6, label: 'Good 6+' },
];

const SORTS = [
  { id: 'recommended', label: 'Our top picks' },
  { id: 'price-asc', label: 'Price (lowest first)' },
  { id: 'price-desc', label: 'Price (highest first)' },
  { id: 'rating', label: 'Guest rating (high to low)' },
  { id: 'stars', label: 'Star rating (5 to 1)' },
  { id: 'distance', label: 'Distance from centre' },
];

const REVIEWS = [
  { name: 'Sophie', country: 'United Kingdom', date: 'Reviewed 3 days ago', score: 9.6, title: 'Absolutely faultless', comment: 'From the warm welcome at check-in to the stunning views from our room, everything felt effortless. The staff remembered our names and the breakfast spread was the best we have had in Dubai.' },
  { name: 'Rahul', country: 'India', date: 'Reviewed 1 week ago', score: 9.2, title: 'Would return in a heartbeat', comment: 'Spotless rooms, comfortable beds and a location that made getting around so easy. The rooftop pool at sunset is worth the trip alone.' },
  { name: 'Emma', country: 'Australia', date: 'Reviewed 2 weeks ago', score: 8.8, title: 'Great value for the location', comment: 'Really comfortable stay. The gym was well equipped and the staff helped us book a desert safari without any hassle at all.' },
  { name: 'Ahmed', country: 'Egypt', date: 'Reviewed 2 weeks ago', score: 9.4, title: 'Outstanding service', comment: 'The team went above and beyond. A small issue with the air conditioning was fixed within ten minutes. Breakfast had huge variety and changed daily.' },
  { name: 'Maria', country: 'Spain', date: 'Reviewed 3 weeks ago', score: 8.5, title: 'Lovely stay, minor quibbles', comment: 'Beautiful lobby and very clean rooms. Wi-Fi was a little slow in the evenings but everything else more than made up for it.' },
  { name: 'Kenji', country: 'Japan', date: 'Reviewed 1 month ago', score: 9.0, title: 'Exactly as pictured', comment: 'The photos do not lie. The pool area is spectacular and the room was quiet despite the busy area outside. Would happily stay again.' },
  { name: 'Olivia', country: 'Canada', date: 'Reviewed 1 month ago', score: 8.9, title: 'Perfect family stay', comment: 'The kids loved the pool and the daily activities. Our family room was huge with a great bathroom, and the buffet had something for everyone.' },
  { name: 'Dmitri', country: 'Russia', date: 'Reviewed 1 month ago', score: 8.2, title: 'Good, with room to improve', comment: 'Comfortable bed and a great location near the metro. Check-in took a while at peak time, but the staff were friendly throughout.' },
  { name: 'Fatima', country: 'United Arab Emirates', date: 'Reviewed 2 months ago', score: 9.5, title: 'A true hidden gem', comment: 'We booked for one night and extended to three. The spa treatment was world class and the terrace restaurant is beautiful after dark.' },
  { name: 'Lucas', country: 'Brazil', date: 'Reviewed 2 months ago', score: 8.7, title: 'Solid choice in Dubai', comment: 'Modern hotel, helpful concierge and easy access to the mall. Housekeeping was excellent and the room was always spotless.' },
  { name: 'Chen', country: 'China', date: 'Reviewed 2 months ago', score: 8.4, title: 'Comfortable and convenient', comment: 'Good size room, powerful shower and very quiet at night. The airport shuttle saved us a lot of planning on arrival.' },
  { name: 'Isabella', country: 'Italy', date: 'Reviewed 3 months ago', score: 9.1, title: 'Romantic getaway winner', comment: 'We loved every minute of it. Sunset views, attentive staff and a gorgeous pool. The room upgrade on arrival was a lovely surprise.' },
];

/* ------------------------------- hotel dataset ------------------------------ */

const RAW = [
  {
    id: 'burj-al-arab-jumeirah', name: 'Burj Al Arab Jumeirah', area: 'Jumeirah Beach Road', type: 'Hotel', stars: 5,
    rating: 9.4, reviews: 21347, price: 1420, oldPrice: 1650, taxes: 182, distance: 4.6, deal: null,
    breakfast: false, freeCancel: true, payLater: true, noPrepay: true, sustainable: false,
    address: 'Jumeirah Beach Road, Umm Suqeim 3, Dubai', checkIn: '15:00 – 23:30', checkOut: '07:00 – 12:00',
    desc: 'Rising 56 storeys on its own island, the iconic sail-shaped Burj Al Arab Jumeirah defines modern luxury. Every suite spans two floors with floor-to-ceiling windows over the Arabian Gulf, and a dedicated butler is on call around the clock.',
    highlights: ['Iconic sail-shaped silhouette on a private island', 'Dedicated butler service on every floor', 'Sky-high dining 200 m above the Arabian Gulf'],
    amenities: ['Free WiFi', 'Swimming pool', 'Spa & wellness centre', 'Fitness centre', 'Restaurant', 'Bar', 'Room service', 'Airport shuttle', 'Beachfront', '24-hour front desk', 'Terrace', 'Non-smoking rooms'],
    landmarks: [{ name: 'Wild Wadi Waterpark', d: '1.4 km' }, { name: 'Madinat Jumeirah', d: '2.2 km' }, { name: 'Kite Beach', d: '3.1 km' }],
  },
  {
    id: 'atlantis-the-palm', name: 'Atlantis The Palm', area: 'Palm Jumeirah', type: 'Resort', stars: 5,
    rating: 9.0, reviews: 25891, price: 456, oldPrice: 560, taxes: 61, distance: 9.4, deal: 'limited',
    breakfast: false, freeCancel: true, payLater: true, noPrepay: false, sustainable: false,
    address: 'Crescent Road, Palm Jumeirah, Dubai', checkIn: '15:00 – 00:00', checkOut: '07:00 – 12:00',
    desc: 'A landmark resort at the apex of Palm Jumeirah, Atlantis pairs marine adventures with five-star comfort. Guests enjoy unlimited access to Aquaventure Waterpark and The Lost Chambers aquarium, plus 17 restaurants and bars.',
    highlights: ['Unlimited Aquaventure Waterpark access included', 'The Lost Chambers aquarium on site', '17 restaurants, bars and lounges'],
    amenities: ['Free WiFi', 'Swimming pool', 'Water park access', 'Spa & wellness centre', 'Fitness centre', 'Restaurant', 'Bar', 'Room service', 'Airport shuttle', 'Family rooms', 'Beachfront', 'EV charging station'],
    landmarks: [{ name: 'Aquaventure Waterpark', d: 'On site' }, { name: 'The Lost Chambers', d: 'On site' }, { name: 'Nakheel Mall', d: '1.8 km' }],
  },
  {
    id: 'armani-hotel-dubai', name: 'Armani Hotel Dubai', area: 'Downtown Dubai', type: 'Hotel', stars: 5,
    rating: 9.1, reviews: 6832, price: 618, oldPrice: null, taxes: 79, distance: 1.1, deal: null,
    breakfast: true, freeCancel: true, payLater: false, noPrepay: true, sustainable: false,
    address: 'Burj Khalifa, 1 Mohammed bin Rashid Blvd, Downtown Dubai', checkIn: '15:00 – 00:00', checkOut: '07:00 – 12:00',
    desc: 'Occupying 11 floors of the world\'s tallest tower, Armani Hotel Dubai delivers Giorgio Armani\'s restrained elegance in every detail, from the bespoke furnishings to the aromatherapy-scented corridors.',
    highlights: ['Located inside the iconic Burj Khalifa', 'Every detail designed by Giorgio Armani', 'Direct access to The Dubai Mall'],
    amenities: ['Free WiFi', 'Swimming pool', 'Spa & wellness centre', 'Fitness centre', 'Restaurant', 'Bar', 'Room service', 'Airport shuttle', 'Business centre', '24-hour front desk', 'Non-smoking rooms'],
    landmarks: [{ name: 'Burj Khalifa', d: 'On site' }, { name: 'The Dubai Mall', d: '0.5 km' }, { name: 'The Dubai Fountain', d: '0.7 km' }],
  },
  {
    id: 'address-beach-resort', name: 'Address Beach Resort', area: 'Jumeirah Beach Residence', type: 'Resort', stars: 5,
    rating: 8.9, reviews: 12455, price: 392, oldPrice: 465, taxes: 52, distance: 16.4, deal: 'genius',
    breakfast: false, freeCancel: true, payLater: false, noPrepay: false, sustainable: true,
    address: 'The Beach, Jumeirah Beach Residence, Dubai', checkIn: '15:00 – 00:00', checkOut: '07:00 – 12:00',
    desc: 'Towering over JBR\'s golden shoreline, Address Beach Resort pairs a rooftop infinity pool 100 metres up with direct private beach access, five restaurants and the award-winning Spa at Address.',
    highlights: ['Rooftop infinity pool with panoramic Gulf views', 'Direct private beach access on JBR', 'Kids club and connecting family suites'],
    amenities: ['Free WiFi', 'Swimming pool', 'Spa & wellness centre', 'Fitness centre', 'Restaurant', 'Bar', 'Room service', 'Beachfront', 'Family rooms', 'Airport shuttle', '24-hour front desk'],
    landmarks: [{ name: 'The Beach JBR', d: '0.3 km' }, { name: 'Ain Dubai', d: '1.2 km' }, { name: 'Marina Mall', d: '2.4 km' }],
  },
  {
    id: 'one-and-only-the-palm', name: 'One&Only The Palm', area: 'Palm Jumeirah', type: 'Resort', stars: 5,
    rating: 9.2, reviews: 5301, price: 538, oldPrice: null, taxes: 70, distance: 8.9, deal: null,
    breakfast: true, freeCancel: true, payLater: false, noPrepay: true, sustainable: true,
    address: 'Kings Way, Palm Jumeirah, Dubai', checkIn: '15:00 – 23:00', checkOut: '07:00 – 12:00',
    desc: 'An intimate garden estate of mansions and low-rise rooms on the Palm\'s quiet trunk, reached by private speedboat. Trails of frangipani lead to a private marina, a lagoon-style pool and the serene Guerlain Spa.',
    highlights: ['Intimate garden estate setting', 'Private marina and lagoon kayaking', 'Arrive by speedboat from the mainland'],
    amenities: ['Free WiFi', 'Swimming pool', 'Spa & wellness centre', 'Fitness centre', 'Restaurant', 'Bar', 'Room service', 'Beachfront', 'Airport shuttle', 'Terrace', 'Non-smoking rooms', '24-hour front desk'],
    landmarks: [{ name: 'One&Only Marina', d: 'On site' }, { name: 'Atlantis The Palm', d: '3.5 km' }, { name: 'Nakheel Mall', d: '4.1 km' }],
  },
  {
    id: 'raffles-dubai', name: 'Raffles Dubai', area: 'Sheikh Zayed Road', type: 'Hotel', stars: 5,
    rating: 9.0, reviews: 9276, price: 312, oldPrice: 360, taxes: 42, distance: 4.9, deal: null,
    breakfast: false, freeCancel: true, payLater: true, noPrepay: false, sustainable: true,
    address: 'Sheikh Rashid Road, Oud Metha, Dubai', checkIn: '15:00 – 00:00', checkOut: '07:00 – 12:00',
    desc: 'An Egyptian-inspired pyramid guarding a one-hectare botanical sky garden, Raffles Dubai offers palatial suites from 58 m², legendary butler service and the tranquil Raffles Spa with Asian-inspired rituals.',
    highlights: ['Botanical sky garden with 1,300+ plants', 'Signature Raffles butler service', 'Wisteria rooftop lounge with skyline views'],
    amenities: ['Free WiFi', 'Swimming pool', 'Spa & wellness centre', 'Fitness centre', 'Restaurant', 'Bar', 'Room service', 'Business centre', 'Airport shuttle', 'Family rooms', '24-hour front desk', 'Non-smoking rooms'],
    landmarks: [{ name: 'Wafi Mall', d: '0.4 km' }, { name: 'Dubai Creek', d: '3.2 km' }, { name: 'Burj Khalifa', d: '4.8 km' }],
  },
  {
    id: 'four-seasons-jumeirah', name: 'Four Seasons Resort Dubai at Jumeirah Beach', area: 'Jumeirah Beach', type: 'Resort', stars: 5,
    rating: 9.3, reviews: 7164, price: 482, oldPrice: 559, taxes: 64, distance: 5.3, deal: null,
    breakfast: true, freeCancel: true, payLater: false, noPrepay: false, sustainable: true,
    address: 'Jumeirah Beach Road, Jumeirah 2, Dubai', checkIn: '15:00 – 00:00', checkOut: '07:00 – 12:00',
    desc: 'A beachfront village of low-rise Arabian architecture, Four Seasons Jumeirah spreads across three temperature-controlled pools, a natural private beach and the pearl-white Pearl Spa & Wellness suite.',
    highlights: ['Natural private beach on the Arabian Gulf', 'Kids For All Seasons supervised club', 'Three temperature-controlled pools'],
    amenities: ['Free WiFi', 'Swimming pool', 'Spa & wellness centre', 'Fitness centre', 'Restaurant', 'Bar', 'Room service', 'Beachfront', 'Family rooms', 'Airport shuttle', 'Non-smoking rooms', 'Terrace'],
    landmarks: [{ name: 'Sunset Mall', d: '1.1 km' }, { name: 'Kite Beach', d: '1.9 km' }, { name: 'Burj Al Arab', d: '3.4 km' }],
  },
  {
    id: 'palazzo-versace-dubai', name: 'Palazzo Versace Dubai', area: 'Culture Village', type: 'Hotel', stars: 5,
    rating: 8.6, reviews: 8913, price: 268, oldPrice: 320, taxes: 36, distance: 6.7, deal: 'limited',
    breakfast: false, freeCancel: true, payLater: false, noPrepay: true, sustainable: false,
    address: 'Jaddaf Waterfront, Culture Village, Dubai', checkIn: '15:00 – 00:00', checkOut: '07:00 – 12:00',
    desc: 'A neoclassical palace on the Dubai Creek waterfront where every furnishing, from the Medusa heads to the marble mosaic floors, carries the Versace Home label. Lagoon-style pools wind beneath palm-lined promenades.',
    highlights: ['Fully Versace-designed interiors', 'Lagoon-style pools with private cabanas', 'On-site marina promenade dining'],
    amenities: ['Free WiFi', 'Swimming pool', 'Spa & wellness centre', 'Fitness centre', 'Restaurant', 'Bar', 'Room service', 'Airport shuttle', 'Family rooms', '24-hour front desk', 'Non-smoking rooms', 'Business centre'],
    landmarks: [{ name: 'Dubai Creek', d: '2.1 km' }, { name: 'Gold Souk', d: '4.4 km' }, { name: 'Dubai Frame', d: '5.2 km' }],
  },
  {
    id: 'ritz-carlton-dubai', name: 'The Ritz-Carlton, Dubai', area: 'Dubai Marina', type: 'Resort', stars: 5,
    rating: 9.1, reviews: 10052, price: 428, oldPrice: null, taxes: 57, distance: 15.2, deal: null,
    breakfast: true, freeCancel: true, payLater: true, noPrepay: false, sustainable: false,
    address: 'The Walk, Jumeirah Beach Residence, Dubai', checkIn: '15:00 – 00:00', checkOut: '07:00 – 12:00',
    desc: 'A Mediterranean-inspired resort stretching along The Walk at JBR, with a private beach, family pool with waterslides, lush gardens and the celebrated Caravan steakhouse. Afternoons end with gelato at the lobby lounge.',
    highlights: ['Private beach directly on The Walk, JBR', 'Award-winning Caravan steakhouse', 'Family pool with waterslides'],
    amenities: ['Free WiFi', 'Swimming pool', 'Spa & wellness centre', 'Fitness centre', 'Restaurant', 'Bar', 'Room service', 'Beachfront', 'Airport shuttle', 'Family rooms', 'Non-smoking rooms', 'Laundry'],
    landmarks: [{ name: 'The Walk JBR', d: '0.2 km' }, { name: 'Marina Beach', d: '0.4 km' }, { name: 'Bluewaters Island', d: '2.8 km' }],
  },
  {
    id: 'sofitel-dubai-jumeirah-beach', name: 'Sofitel Dubai Jumeirah Beach', area: 'Jumeirah Beach Residence', type: 'Hotel', stars: 5,
    rating: 8.5, reviews: 14208, price: 247, oldPrice: 289, taxes: 33, distance: 16.1, deal: 'genius',
    breakfast: false, freeCancel: true, payLater: false, noPrepay: false, sustainable: false,
    address: 'The Walk, Jumeirah Beach Residence, Dubai', checkIn: '15:00 – 00:00', checkOut: '07:00 – 12:00',
    desc: 'Directly facing The Beach mall on JBR, Sofitel Dubai blends French art de recevoir with Arabian warmth. Two temperature-controlled pools, the So Spa hammam and a private beach club keep days full.',
    highlights: ['Directly facing The Beach mall on JBR', 'Two temperature-controlled pools', 'So Spa with traditional hammam'],
    amenities: ['Free WiFi', 'Swimming pool', 'Fitness centre', 'Restaurant', 'Bar', 'Room service', 'Beachfront', 'Family rooms', 'Airport shuttle', '24-hour front desk', 'Business centre', 'Non-smoking rooms'],
    landmarks: [{ name: 'The Beach JBR', d: '0.1 km' }, { name: 'Ain Dubai', d: '1.4 km' }, { name: 'Marina Mall', d: '3.0 km' }],
  },
  {
    id: 'grand-hyatt-dubai', name: 'Grand Hyatt Dubai', area: 'Business Bay', type: 'Hotel', stars: 5,
    rating: 8.7, reviews: 16437, price: 198, oldPrice: 235, taxes: 27, distance: 5.6, deal: 'limited',
    breakfast: false, freeCancel: true, payLater: true, noPrepay: false, sustainable: false,
    address: 'Sheikh Rashid Road, Oud Metha, Dubai', checkIn: '15:00 – 00:00', checkOut: '07:00 – 12:00',
    desc: 'Built around Dubai\'s grandest hotel atrium, Grand Hyatt spreads across 37 acres of landscaped gardens with 1.5 acres of pools, nine restaurants and the pampering Grand Spa. Business travellers love the direct conference centre.',
    highlights: ['Dubai\'s grandest hotel atrium', '1.5 acres of landscaped pools', '9 restaurants and bars'],
    amenities: ['Free WiFi', 'Swimming pool', 'Spa & wellness centre', 'Fitness centre', 'Restaurant', 'Bar', 'Room service', 'Business centre', 'Airport shuttle', 'Family rooms', '24-hour front desk', 'EV charging station'],
    landmarks: [{ name: 'Dubai Creek', d: '2.4 km' }, { name: 'Dubai Frame', d: '3.8 km' }, { name: 'Burj Khalifa', d: '5.1 km' }],
  },
  {
    id: 'paramount-hotel-dubai', name: 'Paramount Hotel Dubai', area: 'Business Bay', type: 'Hotel', stars: 5,
    rating: 8.4, reviews: 11390, price: 174, oldPrice: null, taxes: 24, distance: 4.8, deal: 'new',
    breakfast: false, freeCancel: true, payLater: true, noPrepay: true, sustainable: false,
    address: 'Marasi Drive, Business Bay, Dubai', checkIn: '15:00 – 00:00', checkOut: '07:00 – 12:00',
    desc: 'Hollywood golden-age glamour on the Dubai Water Canal. Sound-engineered quiet rooms, a private screening room and a rooftop pool framed by the skyline make Paramount a cinematic stay for creatives and families alike.',
    highlights: ['Hollywood golden-age glamour theme', 'Sound-engineered quiet suites', 'Private cinema screening room'],
    amenities: ['Free WiFi', 'Swimming pool', 'Fitness centre', 'Restaurant', 'Bar', 'Room service', 'Business centre', 'Airport shuttle', '24-hour front desk', 'Non-smoking rooms', 'Laundry'],
    landmarks: [{ name: 'Dubai Water Canal', d: '0.9 km' }, { name: 'Business Bay Metro', d: '0.6 km' }, { name: 'Burj Khalifa', d: '3.6 km' }],
  },
  {
    id: 'vida-downtown', name: 'Vida Downtown', area: 'Downtown Dubai', type: 'Hotel', stars: 4,
    rating: 8.9, reviews: 8755, price: 212, oldPrice: 245, taxes: 28, distance: 1.4, deal: null,
    breakfast: true, freeCancel: true, payLater: false, noPrepay: false, sustainable: false,
    address: 'Downtown Dubai, Mohammed bin Rashid Blvd, Dubai', checkIn: '15:00 – 00:00', checkOut: '07:00 – 12:00',
    desc: 'A boutique urban retreat at the foot of Burj Khalifa, Vida Downtown pairs lakeside infinity-pool days with street-side café culture. The Address Group\'s younger brand keeps it design-led, social and central.',
    highlights: ['Four-minute walk to Burj Khalifa', 'Lakeside infinity pool', 'Street-side café and dining terrace'],
    amenities: ['Free WiFi', 'Swimming pool', 'Fitness centre', 'Restaurant', 'Bar', 'Room service', 'Family rooms', 'Business centre', 'Non-smoking rooms', '24-hour front desk', 'Terrace'],
    landmarks: [{ name: 'Burj Khalifa', d: '0.8 km' }, { name: 'Dubai Opera', d: '1.0 km' }, { name: 'The Dubai Mall', d: '1.1 km' }],
  },
  {
    id: 'rove-downtown', name: 'Rove Downtown', area: 'Downtown Dubai', type: 'Hotel', stars: 3,
    rating: 8.7, reviews: 19675, price: 92, oldPrice: 110, taxes: 12, distance: 1.7, deal: 'genius',
    breakfast: true, freeCancel: true, payLater: true, noPrepay: true, sustainable: true,
    address: '2nd of December Street, Downtown Dubai, Dubai', checkIn: '15:00 – 00:00', checkOut: '07:00 – 12:00',
    desc: 'Dubai\'s homegrown budget-smart brand, Rove Downtown sits beside the Dubai Mall fountains. Punchy design, a 24/7 gym and pool, and free high-speed Wi-Fi make it the value king of Downtown.',
    highlights: ['Budget-smart design hotel', '24/7 gym and outdoor pool', 'Next to Dubai Mall and the fountain show'],
    amenities: ['Free WiFi', 'Swimming pool', 'Fitness centre', 'Restaurant', 'Bar', 'Room service', 'Family rooms', 'Laundry', '24-hour front desk', 'Non-smoking rooms'],
    landmarks: [{ name: 'The Dubai Mall', d: '0.9 km' }, { name: 'Burj Khalifa', d: '1.2 km' }, { name: 'Dubai Aquarium', d: '1.0 km' }],
  },
  {
    id: 'steigenberger-hotel-deira', name: 'Steigenberger Hotel Deira', area: 'Deira', type: 'Hotel', stars: 5,
    rating: 8.2, reviews: 6221, price: 142, oldPrice: 168, taxes: 19, distance: 7.2, deal: null,
    breakfast: false, freeCancel: true, payLater: true, noPrepay: false, sustainable: false,
    address: 'Al Rigga Road, Deira, Dubai', checkIn: '15:00 – 00:00', checkOut: '07:00 – 12:00',
    desc: 'German precision meets Deira\'s old-Dubai charm. A rooftop pool with city views, a traditional hammam and a short metro hop to the Gold Souk make Steigenberger a smart base for explorers.',
    highlights: ['Rooftop pool with old-city views', 'Steps from the Gold Souk', 'Traditional spa and hammam'],
    amenities: ['Free WiFi', 'Swimming pool', 'Spa & wellness centre', 'Fitness centre', 'Restaurant', 'Bar', 'Room service', 'Business centre', 'Airport shuttle', '24-hour front desk', 'Non-smoking rooms'],
    landmarks: [{ name: 'Al Rigga Metro', d: '0.4 km' }, { name: 'Gold Souk', d: '1.6 km' }, { name: 'Dubai Creek', d: '2.6 km' }],
  },
  {
    id: 'marina-view-apartments', name: 'Dubai Marina View Apartments', area: 'Dubai Marina', type: 'Apartment', stars: 4,
    rating: 8.4, reviews: 3418, price: 128, oldPrice: null, taxes: 17, distance: 15.5, deal: 'new',
    breakfast: false, freeCancel: false, payLater: true, noPrepay: true, sustainable: false,
    address: 'Marina Walk, Dubai Marina, Dubai', checkIn: '15:00 – 22:00', checkOut: '08:00 – 11:00',
    desc: 'Serviced apartments with private balconies hanging right over the Marina Walk. Each unit has a full kitchen, washer-dryer and floor-to-ceiling glass framing the yacht-dotted water below.',
    highlights: ['Private balcony with marina views', 'Full kitchen and in-unit laundry', 'Six-minute walk to the metro'],
    amenities: ['Free WiFi', 'Swimming pool', 'Fitness centre', 'Kitchenette', 'Laundry', 'Free parking', 'Family rooms', 'Air conditioning', '24-hour front desk', 'Terrace'],
    landmarks: [{ name: 'Marina Mall', d: '0.8 km' }, { name: 'JBR Beach', d: '1.9 km' }, { name: 'DMCC Metro', d: '0.6 km' }],
  },
  {
    id: 'address-residences-opera', name: 'Address Residences Dubai Opera', area: 'Downtown Dubai', type: 'Apartment', stars: 5,
    rating: 8.8, reviews: 2976, price: 236, oldPrice: 275, taxes: 31, distance: 1.0, deal: null,
    breakfast: true, freeCancel: true, payLater: false, noPrepay: false, sustainable: true,
    address: 'Sheikh Mohammed bin Rashid Blvd, Downtown Dubai, Dubai', checkIn: '15:00 – 00:00', checkOut: '07:00 – 12:00',
    desc: 'Serviced residence living beside Dubai Opera, with hotel-style housekeeping, a 63rd-floor sky pool and direct access to The Dubai Mall through the boulevard. Ideal for longer stays that refuse to compromise.',
    highlights: ['Serviced residence living beside Dubai Opera', 'Sky pool on level 63', 'Direct access to The Dubai Mall'],
    amenities: ['Free WiFi', 'Swimming pool', 'Fitness centre', 'Kitchenette', 'Restaurant', 'Bar', 'Room service', 'Family rooms', 'Business centre', 'Non-smoking rooms', '24-hour front desk', 'Laundry'],
    landmarks: [{ name: 'Dubai Opera', d: '0.2 km' }, { name: 'Burj Khalifa', d: '0.7 km' }, { name: 'The Dubai Mall', d: '0.9 km' }],
  },
  {
    id: 'palm-oasis-private-villas', name: 'Palm Oasis Private Villas', area: 'Palm Jumeirah', type: 'Villa', stars: 5,
    rating: 9.0, reviews: 1240, price: 526, oldPrice: null, taxes: 68, distance: 9.8, deal: null,
    breakfast: true, freeCancel: true, payLater: true, noPrepay: true, sustainable: false,
    address: 'Frond K, Palm Jumeirah, Dubai', checkIn: '16:00 – 23:00', checkOut: '08:00 – 11:00',
    desc: 'A collection of four- and five-bedroom villas on the Palm\'s fronds, each with a heated private plunge pool, garden and direct beach access. A private chef and butler can be arranged on request.',
    highlights: ['Heated private plunge pool', 'Direct beach access from the garden', 'Private chef and butler on request'],
    amenities: ['Private pool', 'Free WiFi', 'Kitchenette', 'Free parking', 'Airport shuttle', 'Family rooms', 'Terrace', 'Pet friendly', 'Air conditioning', 'Laundry', '24-hour front desk', 'Garden'],
    landmarks: [{ name: 'Palm West Beach', d: '1.1 km' }, { name: 'Atlantis The Palm', d: '2.4 km' }, { name: 'Nakheel Mall', d: '3.2 km' }],
  },
  {
    id: 'jumeirah-beach-escape-villa', name: 'Jumeirah Beach Escape Villa', area: 'Jumeirah', type: 'Villa', stars: 4,
    rating: 8.8, reviews: 864, price: 384, oldPrice: 450, taxes: 49, distance: 5.9, deal: 'limited',
    breakfast: false, freeCancel: true, payLater: false, noPrepay: false, sustainable: false,
    address: 'Jumeirah 1, near Kite Beach, Dubai', checkIn: '16:00 – 22:00', checkOut: '08:00 – 11:00',
    desc: 'A relaxed four-bedroom family villa five minutes\' walk from Kite Beach. The shaded garden has a BBQ terrace and private pool, while cots, high chairs and beach toys come free of charge.',
    highlights: ['Four bedrooms with garden BBQ', 'Five-minute walk to Kite Beach', 'Cot, high chair and beach toys included'],
    amenities: ['Private pool', 'Free WiFi', 'Kitchenette', 'Free parking', 'Family rooms', 'Terrace', 'Pet friendly', 'Air conditioning', 'Laundry', 'Garden'],
    landmarks: [{ name: 'Kite Beach', d: '0.7 km' }, { name: 'Sunset Mall', d: '1.4 km' }, { name: 'Burj Al Arab', d: '2.9 km' }],
  },
  {
    id: 'the-cactus-hostel-dubai', name: 'The Cactus Hostel Dubai', area: 'Deira', type: 'Hostel', stars: 2,
    rating: 8.0, reviews: 4559, price: 36, oldPrice: 44, taxes: 5, distance: 7.8, deal: null,
    breakfast: false, freeCancel: false, payLater: true, noPrepay: true, sustainable: true,
    address: 'Al Rigga Road, Deira, Dubai', checkIn: '14:00 – 00:00', checkOut: '07:00 – 11:00',
    desc: 'Old Dubai\'s friendliest budget stay: a rooftop terrace with skyline views, female-only dorm floors, a shared kitchen and a three-minute walk to the metro. Free walking tours leave every morning.',
    highlights: ['Rooftop terrace with skyline views', 'Female-only dorm floors', 'Three-minute walk to the metro'],
    amenities: ['Free WiFi', 'Shared lounge', 'Kitchenette', 'Laundry', 'Air conditioning', '24-hour front desk', 'Non-smoking rooms'],
    landmarks: [{ name: 'Al Rigga Metro', d: '0.3 km' }, { name: 'Deira City Centre', d: '1.7 km' }, { name: 'Gold Souk', d: '2.1 km' }],
  },
];

/* --------------------------------- helpers ---------------------------------- */

export const ratingLabel = (s) => {
  if (s >= 9.2) return 'Exceptional';
  if (s >= 8.8) return 'Wonderful';
  if (s >= 8.2) return 'Excellent';
  if (s >= 7.5) return 'Very good';
  return 'Good';
};

const ratingCats = (r) => {
  const j = (v) => Math.max(5, Math.min(9.8, Math.round(v * 10) / 10));
  return {
    Cleanliness: j(r + 0.3),
    Comfort: j(r + 0.1),
    Location: j(r - 0.2),
    Facilities: j(r + 0.2),
    Staff: j(r + 0.4),
    'Value for money': j(r - 0.5),
    'Free WiFi': j(r + 0.2),
  };
};

const genRooms = (h, i) => {
  const names = {
    Hotel: ['Classic Double Room', 'Deluxe King Room', 'Executive Suite', 'Family Room with Balcony'],
    Resort: ['Garden View Double Room', 'Ocean View King Room', 'Beachfront Suite', 'Family Room with Balcony'],
    Apartment: ['Studio Apartment', 'One-Bedroom Apartment', 'Deluxe Two-Bedroom Apartment', 'Penthouse Apartment'],
    Villa: ['Garden Villa', 'Private Pool Villa', 'Deluxe Villa', 'Beachfront Villa'],
    Hostel: ['Bed in 6-Bed Mixed Dorm', 'Private Double Room', 'Bed in 4-Bed Female Dorm', 'Twin Room'],
  }[h.type];
  const beds = ['1 queen bed', '1 king bed', '1 king bed + sofa bed', '2 double beds'];
  const guests = [2, 2, 3, 4];
  const sizes = [32, 44, 68, 54];
  const mults = [1, 1.28, 1.68, 1.42];
  return names.map((n, j) => ({
    name: n,
    bed: beds[j],
    guests: guests[j],
    size: h.type === 'Villa' ? sizes[j] * 3 : h.type === 'Hostel' ? sizes[j] : sizes[j] + 4,
    price: Math.round((h.price * mults[j]) / 5) * 5,
    img: ROOMS[(i + j) % ROOMS.length],
    benefits: [
      h.freeCancel && j < 2 ? 'Free cancellation before 24 hours' : 'Non-refundable — save 5%',
      h.breakfast && j === 1 ? 'Breakfast included' : 'Breakfast available',
      j === 2 ? 'Free airport shuttle' : 'Pay at the property',
    ],
  }));
};

/** Static, always-available sample dataset (kept exactly as before). */
export const HOTELS = RAW.map((h, i) => {
  const seed = h.id.split('').reduce((a, c) => a + c.charCodeAt(0), 0);
  const main = i < 10 ? DUBAI[i] : EXTERIORS[i - 10];
  return {
    ...h,
    image: main,
    gallery: [main, ROOMS[i % ROOMS.length], POOLS[i % POOLS.length], LOBBIES[i % LOBBIES.length], ROOMS[(i + 4) % ROOMS.length], POOLS[(i + 6) % POOLS.length]],
    cats: ratingCats(h.rating),
    rooms: genRooms(h, i),
    guestReviews: [REVIEWS[i % REVIEWS.length], REVIEWS[(i + 3) % REVIEWS.length], REVIEWS[(i + 7) % REVIEWS.length]],
    mapX: 12 + (seed % 76),
    mapY: 12 + ((seed * 7) % 70),
  };
});

/* ------------------------------- sub components ----------------------------- */

export function Stars({ n, size = 14 }) {
  return (
    <span className="hl-stars">
      {[1, 2, 3, 4, 5].map((i) => (
        <Star key={i} size={size} className={i <= n ? 'on' : 'off'} fill={i <= n ? 'currentColor' : 'none'} />
      ))}
    </span>
  );
}

function HotelCard({ h, nights, adults, wished, onWish }) {
  const save = h.oldPrice ? h.oldPrice - h.price : 0;
  return (
    <article className="hl-card">
      <div className="hl-card-media">
        <Link to={`/hotel/${h.id}`} className="hl-card-img">
          <img src={h.image} alt={h.name} loading="lazy" />
        </Link>
        {h.deal === 'limited' && <span className="hl-badge deal">Limited-time deal</span>}
        {h.deal === 'genius' && <span className="hl-badge genius">10% Genius deal</span>}
        {h.deal === 'new' && <span className="hl-badge fresh">Newly opened</span>}
        {h.source === 'admin' && <span className="hl-badge fresh" style={{ background: '#0b2545' }}>Admin listed</span>}
        <button
          className={`hl-wish ${wished ? 'on' : ''}`}
          onClick={() => onWish(h.id)}
          aria-label="Save to wishlist"
          title={wished ? 'Remove from wishlist' : 'Save to wishlist'}
        >
          <Heart size={17} fill={wished ? 'currentColor' : 'none'} />
        </button>
      </div>

      <div className="hl-card-body">
        <div className="hl-card-top">
          <div>
            <h3 className="hl-card-name">
              <Link to={`/hotel/${h.id}`}>{h.name}</Link>
            </h3>
            <Stars n={h.stars} size={13} />
          </div>
          <div className="hl-rating">
            <span className="hl-rating-box">{h.rating.toFixed(1)}</span>
            <span className="hl-rating-txt">
              <b>{ratingLabel(h.rating)}</b>
              <em>{h.reviews.toLocaleString()} reviews</em>
            </span>
          </div>
        </div>

        <p className="hl-card-loc">
          <MapPin size={13} /> {h.area}, Dubai &middot; {h.distance} km from centre
        </p>

        <div className="hl-card-high">
          {(h.highlights || []).slice(0, 2).map((hi) => (
            <span key={hi}><Sparkles size={12} /> {hi}</span>
          ))}
          {h.sustainable && <span className="green"><Leaf size={12} /> Sustainable property</span>}
        </div>

        <div className="hl-card-amen">
          {(h.amenities || []).slice(0, 8).map((a) => {
            const Ic = AMENITY_ICONS[a] || Check;
            return (
              <span key={a} title={a}><Ic size={15} /></span>
            );
          })}
          <em>+{Math.max(0, (h.amenities || []).length - 8)} more</em>
        </div>

        <div className="hl-card-tags">
          {h.freeCancel && <span className="t green"><ShieldCheck size={12} /> Free cancellation</span>}
          {h.noPrepay && <span className="t"><Banknote size={12} /> No prepayment</span>}
          {h.breakfast && <span className="t"><Coffee size={12} /> Breakfast included</span>}
          {h.payLater && <span className="t"><BadgeCheck size={12} /> Pay at property</span>}
        </div>
      </div>

      <div className="hl-card-price">
        {save > 0 && <span className="hl-save">Save ${save.toLocaleString()} tonight</span>}
        <div className="hl-price-line">
          {h.oldPrice && <s>${h.oldPrice.toLocaleString()}</s>}
          <b>${h.price.toLocaleString()}</b>
          <span>/ night</span>
        </div>
        <span className="hl-price-tax">+ ${(h.taxes || 0).toLocaleString()} taxes and fees</span>
        <span className="hl-price-total">${((h.price + (h.taxes || 0)) * nights).toLocaleString()} total · {nights} night{nights > 1 ? 's' : ''}, {adults} adult{adults > 1 ? 's' : ''}</span>
        <Link to={`/hotel/${h.id}`} className="hl-card-cta">
          See availability <ArrowRight size={15} />
        </Link>
      </div>
    </article>
  );
}

function MapView({ hotels, activePin, setActivePin }) {
  const active = hotels.find((h) => h.id === activePin) || null;
  return (
    <div className="hl-map">
      <div className="hl-map-head">
        <span><MapIcon size={15} /> Dubai · {hotels.length} properties on map</span>
        <span className="hl-map-zoom">
          <button>+</button>
          <button>&minus;</button>
        </span>
      </div>
      <div className="hl-map-canvas">
        <div className="hl-map-water w1" />
        <div className="hl-map-water w2" />
        <div className="hl-map-road r1" />
        <div className="hl-map-road r2" />
        <div className="hl-map-road r3" />
        <span className="hl-map-label" style={{ top: '16%', left: '8%' }}>DUBAI MARINA</span>
        <span className="hl-map-label" style={{ top: '58%', left: '6%' }}>JUMEIRAH</span>
        <span className="hl-map-label" style={{ top: '34%', left: '56%' }}>DOWNTOWN</span>
        <span className="hl-map-label" style={{ top: '78%', left: '66%' }}>DEIRA</span>
        <span className="hl-map-label" style={{ top: '24%', left: '30%' }}>PALM JUMEIRAH</span>
        {hotels.map((h) => (
          <button
            key={h.id}
            className={`hl-pin ${activePin === h.id ? 'on' : ''}`}
            style={{ left: `${h.mapX}%`, top: `${h.mapY}%` }}
            onClick={() => setActivePin(h.id)}
            title={h.name}
          >
            ${h.price}
          </button>
        ))}
      </div>
      {active && (
        <div className="hl-map-card">
          <img src={active.image} alt={active.name} />
          <div className="hl-map-info">
            <strong>{active.name}</strong>
            <Stars n={active.stars} size={12} />
            <span>{active.area} &middot; {active.distance} km from centre</span>
          </div>
          <div className="hl-map-side">
            <div className="hl-map-price">${active.price}<small>/night</small></div>
            <Link className="hl-map-link" to={`/hotel/${active.id}`}>View details <ArrowRight size={13} /></Link>
          </div>
          <button className="hl-map-close" onClick={() => setActivePin(null)} aria-label="Close">
            <X size={15} />
          </button>
        </div>
      )}
    </div>
  );
}

/* --------------------------------- main page -------------------------------- */

export default function HotelList() {
  const day = 86400000;
  const fmt = (d) => new Date(d).toISOString().slice(0, 10);
  const todayStr = fmt(Date.now());
  const [checkIn, setCheckIn] = useState(fmt(Date.now() + day));
  const [checkOut, setCheckOut] = useState(fmt(Date.now() + 3 * day));
  const [adults, setAdults] = useState(2);
  const [rooms, setRooms] = useState(1);

  const [sort, setSort] = useState('recommended');
  const [sortOpen, setSortOpen] = useState(false);
  const [query, setQuery] = useState('');
  const [priceRange, setPriceRange] = useState([0, 1500]);
  const [starSel, setStarSel] = useState([]);
  const [minRating, setMinRating] = useState(0);
  const [typeSel, setTypeSel] = useState([]);
  const [popSel, setPopSel] = useState([]);
  const [maxDist, setMaxDist] = useState(25);
  const [sustainOnly, setSustainOnly] = useState(false);
  const [payPropOnly, setPayPropOnly] = useState(false);
  const [view, setView] = useState('list');
  const [drawer, setDrawer] = useState(false);
  const [activePin, setActivePin] = useState(null);
  const [wish, setWish] = useState(() => {
    try { return JSON.parse(localStorage.getItem('tn_wishlist')) || []; } catch { return []; }
  });

  /* Admin-added hotels fetched from the backend, merged with the static sample data below */
  const [dbHotels, setDbHotels] = useState([]);
  const [dbLoading, setDbLoading] = useState(true);

  const sortRef = useRef(null);
  const resultsRef = useRef(null);

  const nights = Math.max(1, Math.round((new Date(checkOut) - new Date(checkIn)) / day) || 1);

  useEffect(() => {
    let cancelled = false;
    fetch(`${API_BASE}/api/hotels`)
      .then((r) => r.json())
      .then((data) => {
        if (!cancelled && data && data.success) setDbHotels(data.hotels || []);
      })
      .catch(() => { /* backend not reachable — sample data still shows */ })
      .finally(() => { if (!cancelled) setDbLoading(false); });
    return () => { cancelled = true; };
  }, []);

  /** Combined list: admin-added hotels (newest first) + static sample data */
  const ALL_HOTELS = useMemo(() => [...dbHotels, ...HOTELS], [dbHotels]);

  useEffect(() => {
    const fn = (e) => {
      if (sortRef.current && !sortRef.current.contains(e.target)) setSortOpen(false);
    };
    document.addEventListener('mousedown', fn);
    return () => document.removeEventListener('mousedown', fn);
  }, []);

  useEffect(() => {
    document.body.style.overflow = drawer ? 'hidden' : '';
    return () => { document.body.style.overflow = ''; };
  }, [drawer]);

  const toggleWish = (id) => setWish((w) => {
    const nw = w.includes(id) ? w.filter((x) => x !== id) : [...w, id];
    try { localStorage.setItem('tn_wishlist', JSON.stringify(nw)); } catch { /* ignore */ }
    return nw;
  });

  const toggleArr = (setter, arr, v) => setter(arr.includes(v) ? arr.filter((x) => x !== v) : [...arr, v]);

  const matchesPop = (h, key) => {
    if (key === 'Free cancellation') return h.freeCancel;
    if (key === 'No prepayment') return h.noPrepay;
    if (key === 'Breakfast included') return h.breakfast;
    return (h.amenities || []).includes(key);
  };

  const filtered = useMemo(() => ALL_HOTELS.filter((h) => {
    const q = query.trim().toLowerCase();
    if (q && !h.name.toLowerCase().includes(q) && !h.area.toLowerCase().includes(q)) return false;
    if (h.price < priceRange[0] || h.price > priceRange[1]) return false;
    if (starSel.length && !starSel.includes(h.stars)) return false;
    if (h.rating < minRating) return false;
    if (typeSel.length && !typeSel.includes(h.type)) return false;
    if (popSel.some((k) => !matchesPop(h, k))) return false;
    if (h.distance > maxDist) return false;
    if (sustainOnly && !h.sustainable) return false;
    if (payPropOnly && !h.payLater) return false;
    return true;
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }), [ALL_HOTELS, query, priceRange, starSel, minRating, typeSel, popSel, maxDist, sustainOnly, payPropOnly]);

  const sorted = useMemo(() => {
    const arr = [...filtered];
    switch (sort) {
      case 'price-asc': arr.sort((a, b) => a.price - b.price); break;
      case 'price-desc': arr.sort((a, b) => b.price - a.price); break;
      case 'rating': arr.sort((a, b) => b.rating - a.rating); break;
      case 'stars': arr.sort((a, b) => b.stars - a.stars || b.rating - a.rating); break;
      case 'distance': arr.sort((a, b) => a.distance - b.distance); break;
      default:
        arr.sort((a, b) => (b.deal ? 1 : 0) - (a.deal ? 1 : 0) || b.rating * Math.log(b.reviews + 1) - a.rating * Math.log(a.reviews + 1));
    }
    return arr;
  }, [filtered, sort]);

  const chips = [];
  if (query.trim()) chips.push({ label: `"${query.trim()}"`, clear: () => setQuery('') });
  if (priceRange[0] > 0 || priceRange[1] < 1500) chips.push({ label: `$${priceRange[0]} – $${priceRange[1]} per night`, clear: () => setPriceRange([0, 1500]) });
  starSel.forEach((s) => chips.push({ label: `${s} star${s > 1 ? 's' : ''}`, clear: () => setStarSel((p) => p.filter((x) => x !== s)) }));
  if (minRating > 0) chips.push({ label: `Guest rating ${minRating}+`, clear: () => setMinRating(0) });
  typeSel.forEach((t) => chips.push({ label: t, clear: () => setTypeSel((p) => p.filter((x) => x !== t)) }));
  popSel.forEach((k) => chips.push({ label: k, clear: () => setPopSel((p) => p.filter((x) => x !== k)) }));
  if (maxDist < 25) chips.push({ label: `Within ${maxDist} km of centre`, clear: () => setMaxDist(25) });
  if (sustainOnly) chips.push({ label: 'Sustainable stays', clear: () => setSustainOnly(false) });
  if (payPropOnly) chips.push({ label: 'Pay at property', clear: () => setPayPropOnly(false) });

  const filterCount =
    starSel.length + typeSel.length + popSel.length +
    (minRating ? 1 : 0) + (sustainOnly ? 1 : 0) + (payPropOnly ? 1 : 0) +
    (maxDist < 25 ? 1 : 0) + (priceRange[0] > 0 || priceRange[1] < 1500 ? 1 : 0) + (query.trim() ? 1 : 0);

  const clearAll = () => {
    setQuery(''); setPriceRange([0, 1500]); setStarSel([]); setMinRating(0);
    setTypeSel([]); setPopSel([]); setMaxDist(25); setSustainOnly(false); setPayPropOnly(false);
  };

  const onCheckIn = (e) => {
    const v = e.target.value;
    setCheckIn(v);
    if (new Date(checkOut) <= new Date(v)) setCheckOut(fmt(new Date(v).getTime() + day));
  };

  const filterPanel = (
    <div className="hl-filters">
      <div className="hl-sec">
        <h4>Search by name or area</h4>
        <div className="hl-input">
          <Search size={15} />
          <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="e.g. Marina, Atlantis…" />
          {query && <button onClick={() => setQuery('')} aria-label="Clear"><X size={14} /></button>}
        </div>
      </div>

      <div className="hl-sec">
        <h4>Price per night</h4>
        <div className="hl-range">
          <span className="hl-range-track" />
          <span className="hl-range-fill" style={{ left: `${(priceRange[0] / 1500) * 100}%`, right: `${100 - (priceRange[1] / 1500) * 100}%` }} />
          <input type="range" min="0" max="1500" step="10" value={priceRange[0]}
            onChange={(e) => setPriceRange([Math.min(+e.target.value, priceRange[1] - 50), priceRange[1]])} aria-label="Minimum price" />
          <input type="range" min="0" max="1500" step="10" value={priceRange[1]}
            onChange={(e) => setPriceRange([priceRange[0], Math.max(+e.target.value, priceRange[0] + 50)])} aria-label="Maximum price" />
        </div>
        <div className="hl-range-labels">
          <span>Min ${priceRange[0]}</span>
          <span>Max ${priceRange[1]}{priceRange[1] === 1500 ? '+' : ''}</span>
        </div>
      </div>

      <div className="hl-sec">
        <h4>Star rating</h4>
        {[5, 4, 3, 2, 1].map((s) => {
          const count = ALL_HOTELS.filter((h) => h.stars === s).length;
          return (
            <label key={s} className={`hl-check ${starSel.includes(s) ? 'on' : ''}`}>
              <input type="checkbox" checked={starSel.includes(s)} onChange={() => toggleArr(setStarSel, starSel, s)} />
              <span className="hl-box"><Check size={12} strokeWidth={3} /></span>
              <Stars n={s} size={13} />
              <span className="hl-count">{count}</span>
            </label>
          );
        })}
      </div>

      <div className="hl-sec">
        <h4>Guest rating</h4>
        <div className="hl-chipset">
          {RATING_OPTS.map((o) => (
            <button key={o.v} className={`hl-chip ${minRating === o.v ? 'on' : ''}`} onClick={() => setMinRating(minRating === o.v ? 0 : o.v)}>
              {o.label}
            </button>
          ))}
        </div>
      </div>

      <div className="hl-sec">
        <h4>Property type</h4>
        <div className="hl-chipset">
          {PROPERTY_TYPES.map((t) => {
            const count = ALL_HOTELS.filter((h) => h.type === t).length;
            return (
              <button key={t} className={`hl-chip ${typeSel.includes(t) ? 'on' : ''}`} onClick={() => toggleArr(setTypeSel, typeSel, t)}>
                {t} <em>{count}</em>
              </button>
            );
          })}
        </div>
      </div>

      <div className="hl-sec">
        <h4>Popular filters</h4>
        <div className="hl-chipset">
          {POPULAR_FILTERS.map((f) => {
            const Ic = f.icon;
            const count = ALL_HOTELS.filter((h) => matchesPop(h, f.key)).length;
            return (
              <button key={f.key} className={`hl-chip ${popSel.includes(f.key) ? 'on' : ''}`} onClick={() => toggleArr(setPopSel, popSel, f.key)}>
                <Ic size={13} /> {f.key}
              </button>
            );
          })}
        </div>
      </div>

      <div className="hl-sec">
        <h4>Distance from centre</h4>
        <div className="hl-range single">
          <span className="hl-range-track" />
          <span className="hl-range-fill" style={{ left: 0, right: `${100 - (maxDist / 25) * 100}%` }} />
          <input type="range" min="1" max="25" step="1" value={maxDist} onChange={(e) => setMaxDist(+e.target.value)} aria-label="Distance" />
        </div>
        <div className="hl-range-labels"><span>1 km</span><span>Up to {maxDist} km</span></div>
      </div>

      <div className="hl-sec">
        <h4>Good to know</h4>
        <label className={`hl-check ${sustainOnly ? 'on' : ''}`}>
          <input type="checkbox" checked={sustainOnly} onChange={() => setSustainOnly(!sustainOnly)} />
          <span className="hl-box"><Check size={12} strokeWidth={3} /></span>
          <span className="hl-check-label"><Leaf size={14} className="green-i" /> Sustainable stays <em>{ALL_HOTELS.filter((h) => h.sustainable).length}</em></span>
        </label>
        <label className={`hl-check ${payPropOnly ? 'on' : ''}`}>
          <input type="checkbox" checked={payPropOnly} onChange={() => setPayPropOnly(!payPropOnly)} />
          <span className="hl-box"><Check size={12} strokeWidth={3} /></span>
          <span className="hl-check-label"><Banknote size={14} className="green-i" /> Pay at the property <em>{ALL_HOTELS.filter((h) => h.payLater).length}</em></span>
        </label>
      </div>

      <button className="hl-clear-side" onClick={clearAll}>
        Reset all filters
      </button>
    </div>
  );

  return (
    <div className="hl-app">

      <div className="hl-hero">
        <div className="hl-hero-inner">
          <h1>Find your perfect stay in <span>Dubai</span></h1>
          <p>Search {ALL_HOTELS.length} handpicked hotels, resorts, apartments and villas — free cancellation on most rooms</p>
        </div>
      </div>

      <div className="hl-searchwrap">
        <div className="hl-searchbar">
          <label className="hl-seg grow">
            <MapPin size={17} />
            <span className="hl-seg-body">
              <em>Where are you going?</em>
              <input value={query} onChange={(e) => setQuery(e.target.value)} placeholder="Dubai, area or hotel name" />
            </span>
          </label>
          <label className="hl-seg">
            <CalendarDays size={17} />
            <span className="hl-seg-body">
              <em>Check-in</em>
              <input type="date" min={todayStr} value={checkIn} onChange={onCheckIn} />
            </span>
          </label>
          <label className="hl-seg">
            <CalendarDays size={17} />
            <span className="hl-seg-body">
              <em>Check-out</em>
              <input type="date" min={fmt(new Date(checkIn).getTime() + day)} value={checkOut} onChange={(e) => setCheckOut(e.target.value)} />
            </span>
          </label>
          <label className="hl-seg">
            <Users size={17} />
            <span className="hl-seg-body">
              <em>Guests &amp; rooms</em>
              <span className="hl-seg-selects">
                <select value={adults} onChange={(e) => setAdults(+e.target.value)}>
                  {[1, 2, 3, 4, 5, 6].map((n) => <option key={n} value={n}>{n} adult{n > 1 ? 's' : ''}</option>)}
                </select>
                <select value={rooms} onChange={(e) => setRooms(+e.target.value)}>
                  {[1, 2, 3, 4].map((n) => <option key={n} value={n}>{n} room{n > 1 ? 's' : ''}</option>)}
                </select>
              </span>
            </span>
          </label>
          <button
            className="hl-search-btn"
            onClick={() => resultsRef.current && window.scrollTo({ top: resultsRef.current.offsetTop - 96, behavior: 'smooth' })}
          >
            <Search size={17} /> Search
          </button>
        </div>
      </div>

      <main className="hl-main">
        <div className="hl-crumbs">
          Home <ChevronRight size={12} /> United Arab Emirates <ChevronRight size={12} /> <b>Dubai</b>
        </div>

        <div className="hl-layout">
          <aside className="hl-side">{filterPanel}</aside>

          <section className="hl-results" ref={resultsRef}>
            <div className="hl-results-head">
              <div className="hl-results-title">
                <h1>Dubai: {filtered.length} {filtered.length === 1 ? 'property' : 'properties'} found</h1>
                <p>{nights} night{nights > 1 ? 's' : ''} &middot; {adults} adult{adults > 1 ? 's' : ''} &middot; {rooms} room{rooms > 1 ? 's' : ''} &middot; prices per night before taxes {dbLoading && '· syncing latest listings…'}</p>
              </div>
              <div className="hl-results-tools">
                <div className="hl-sort" ref={sortRef}>
                  <button className="hl-sort-btn" onClick={() => setSortOpen(!sortOpen)}>
                    <ArrowUpDown size={14} />
                    <span>Sort: <b>{SORTS.find((s) => s.id === sort).label}</b></span>
                    <ChevronDown size={14} className={sortOpen ? 'flip' : ''} />
                  </button>
                  {sortOpen && (
                    <div className="hl-sort-menu">
                      {SORTS.map((s) => (
                        <button key={s.id} className={s.id === sort ? 'on' : ''} onClick={() => { setSort(s.id); setSortOpen(false); }}>
                          <Check size={14} style={{ opacity: s.id === sort ? 1 : 0 }} /> {s.label}
                        </button>
                      ))}
                    </div>
                  )}
                </div>
                <div className="hl-viewseg">
                  <button className={view === 'list' ? 'on' : ''} onClick={() => setView('list')}><LayoutGrid size={14} /> List</button>
                  <button className={view === 'map' ? 'on' : ''} onClick={() => setView('map')}><MapIcon size={14} /> Map</button>
                </div>
              </div>
            </div>

            <button className="hl-drawer-open" onClick={() => setDrawer(true)}>
              <SlidersHorizontal size={16} /> Filters
              {filterCount > 0 && <span className="hl-filter-count">{filterCount}</span>}
            </button>

            {chips.length > 0 && (
              <div className="hl-chips-row">
                {chips.map((c, i) => (
                  <button key={i} className="hl-chip on" onClick={c.clear}>
                    {c.label} <X size={12} />
                  </button>
                ))}
                <button className="hl-clearall" onClick={clearAll}>Clear all</button>
              </div>
            )}

            {view === 'map' ? (
              <MapView hotels={sorted} activePin={activePin} setActivePin={setActivePin} />
            ) : (
              <div className="hl-list">
                {sorted.map((h) => (
                  <HotelCard key={h.id} h={h} nights={nights} adults={adults} wished={wish.includes(h.id)} onWish={toggleWish} />
                ))}
                {sorted.length === 0 && (
                  <div className="hl-empty">
                    <Search size={34} />
                    <h3>No properties match your filters</h3>
                    <p>Try widening the price range or removing a few filters.</p>
                    <button onClick={clearAll}>Clear all filters</button>
                  </div>
                )}
              </div>
            )}

            {sorted.length > 0 && (
              <p className="hl-showing">
                Showing {sorted.length} of {ALL_HOTELS.length} properties &middot; Dubai, United Arab Emirates
              </p>
            )}
          </section>
        </div>
      </main>

      <div className={`hl-drawer ${drawer ? 'open' : ''}`}>
        <div className="hl-drawer-bg" onClick={() => setDrawer(false)} />
        <div className="hl-drawer-panel">
          <div className="hl-drawer-head">
            <strong><SlidersHorizontal size={16} /> Filters</strong>
            <button onClick={() => setDrawer(false)} aria-label="Close filters"><X size={18} /></button>
          </div>
          {filterPanel}
          <div className="hl-drawer-cta" onClick={() => setDrawer(false)}>
            Show {filtered.length} {filtered.length === 1 ? 'property' : 'properties'}
          </div>
        </div>
      </div>

      <footer className="hl-footer">
        <div className="hl-footer-inner">
          <div className="hl-footer-brand">
            <span className="hl-brand-mark big">TN</span>
            <p>TravelNest — handpicked stays in the world&apos;s greatest cities. Demo experience inspired by the best of Booking.com and Agoda.</p>
          </div>
          <div className="hl-footer-col">
            <h5>Destinations</h5>
            <a href="#dubai">Dubai hotels</a>
            <a href="#marina">Dubai Marina stays</a>
            <a href="#palm">Palm Jumeirah villas</a>
            <a href="#downtown">Downtown apartments</a>
          </div>
          <div className="hl-footer-col">
            <h5>Support</h5>
            <a href="#help">Help centre</a>
            <a href="#cancel">Cancellation options</a>
            <a href="#covid">Travel guidance</a>
            <a href="#contact">Contact us</a>
          </div>
          <div className="hl-footer-col">
            <h5>Company</h5>
            <a href="#about">About TravelNest</a>
            <a href="#careers">Careers</a>
            <a href="#press">Press</a>
            <a href="#terms">Terms &amp; privacy</a>
          </div>
        </div>
        <div className="hl-footer-base">© 2025 TravelNest demo. Prices, hotels and reviews shown are illustrative.</div>
      </footer>
    </div>
  );
}