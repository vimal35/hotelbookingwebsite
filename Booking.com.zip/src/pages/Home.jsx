import { useEffect, useMemo, useState } from 'react';
import './Home.css';

/* ============ Import Lucide Icons ============ */
import {
  Building2, MapPin, CalendarDays, Search, ChevronDown, Users, Star, Bed,
  ShieldCheck, Wifi, Car, Headphones, Wallet, Plane, Baby, Check, Phone,
  Mail, MapPin as Pin, Globe, CreditCard, Sparkles, ArrowRight, ArrowUpRight,
  Bell, Ticket, Banknote, Quote, Clock, Route, Trees, Coffee,
} from 'lucide-react';

/* ============ DATA ============ */

const destinations = [
  { city: 'Paris', country: 'France', img: 'https://images.pexels.com/photos/30379456/pexels-photo-30379456.jpeg?auto=compress&cs=tinysrgb&w=600', hotels: 248, deals: 32, start: 89 },
  { city: 'Maldives', country: 'Indian Ocean', img: 'https://images.pexels.com/photos/3293192/pexels-photo-3293192.jpeg?auto=compress&cs=tinysrgb&w=900', hotels: 96, deals: 18, start: 150, tall: true },
  { city: 'Dubai', country: 'United Arab Emirates', img: 'https://images.pexels.com/photos/19664340/pexels-photo-19664340.jpeg?auto=compress&cs=tinysrgb&w=600', hotels: 512, deals: 64, start: 105 },
  { city: 'New York', country: 'United States', img: 'https://images.pexels.com/photos/28411366/pexels-photo-28411366.jpeg?auto=compress&cs=tinysrgb&w=600', hotels: 380, deals: 41, start: 135 },
  { city: 'Tokyo', country: 'Japan', img: 'https://images.pexels.com/photos/35072449/pexels-photo-35072449.jpeg?auto=compress&cs=tinysrgb&w=600', hotels: 421, deals: 55, start: 98 },
  { city: 'Santorini', country: 'Greece', img: 'https://images.pexels.com/photos/37911732/pexels-photo-37911732.jpeg?auto=compress&cs=tinysrgb&w=600', hotels: 182, deals: 27, start: 120 },
  { city: 'Bali', country: 'Indonesia', img: 'https://images.pexels.com/photos/32314301/pexels-photo-32314301.jpeg?auto=compress&cs=tinysrgb&w=900', hotels: 305, deals: 49, start: 75 },
  { city: 'Singapore', country: 'Singapore', img: 'https://images.pexels.com/photos/38436984/pexels-photo-38436984.jpeg?auto=compress&cs=tinysrgb&w=900', hotels: 289, deals: 33, start: 92 },
];

const cities = [
  { city: 'New York', country: 'USA' },
  { city: 'Paris', country: 'France' },
  { city: 'London', country: 'United Kingdom' },
  { city: 'Dubai', country: 'UAE' },
  { city: 'Tokyo', country: 'Japan' },
  { city: 'Bali', country: 'Indonesia' },
  { city: 'Maldives', country: 'Indian Ocean' },
  { city: 'Rome', country: 'Italy' },
];

const steps = [
  {
    title: 'Search & Discover',
    desc: 'Tell us where you want to go. Browse 2M+ hotels, resorts and villas across 190 countries with live prices and photos.',
    dur: 'Less than 1 minute',
    img: 'https://images.pexels.com/photos/7368269/pexels-photo-7368269.jpeg?auto=compress&cs=tinysrgb&w=800',
    icon: Search,
  },
  {
    title: 'Compare & Book',
    desc: 'Filter by price, rating, free cancellation and amenities. Compare the best deals side-by-side and instantly confirm your stay.',
    dur: 'Instant confirmation',
    img: 'https://images.pexels.com/photos/7368277/pexels-photo-7368277.jpeg?auto=compress&cs=tinysrgb&w=800',
    icon: CreditCard,
  },
  {
    title: 'Travel & Enjoy',
    desc: 'Get your e-voucher instantly. Enjoy keyless check-in, concierge support and flexible cancellation right from your phone.',
    dur: 'Enjoy your trip',
    img: 'https://images.pexels.com/photos/7368290/pexels-photo-7368290.jpeg?auto=compress&cs=tinysrgb&w=800',
    icon: Plane,
  },
];

const hotels = [
  {
    name: 'Azure Bay Resort', city: 'Maldives', country: 'Indian Ocean',
    img: 'https://images.pexels.com/photos/30037427/pexels-photo-30037427.jpeg?auto=compress&cs=tinysrgb&w=800',
    price: 389, rating: 9.6, reviews: 1284,
    amenities: ['Beachfront', 'Pool', 'Free Cancellation', 'Breakfast'],
    badge: 'Hot Deal',
  },
  {
    name: 'The Grand Meridian', city: 'Paris', country: 'France',
    img: 'https://images.pexels.com/photos/8082217/pexels-photo-8082217.jpeg?auto=compress&cs=tinysrgb&w=800',
    price: 254, rating: 9.2, reviews: 2140,
    amenities: ['City View', 'Spa & Wellness', 'Wi-Fi', 'Breakfast'],
    badge: 'Featured',
  },
  {
    name: 'Riviera Palace', city: 'Dubai', country: 'UAE',
    img: 'https://images.pexels.com/photos/2725675/pexels-photo-2725675.jpeg?auto=compress&cs=tinysrgb&w=800',
    price: 310, rating: 9.4, reviews: 968,
    amenities: ['Skyline View', 'Infinity Pool', 'Free Parking', 'Breakfast'],
    badge: 'Luxury',
  },
  {
    name: 'Ocean Whisper Inn', city: 'Santorini', country: 'Greece',
    img: 'https://images.pexels.com/photos/17976859/pexels-photo-17976859.jpeg?auto=compress&cs=tinysrgb&w=800',
    price: 178, rating: 8.9, reviews: 1520,
    amenities: ['Sea View', 'Free Breakfast', 'Pool', 'Free Cancellation'],
    badge: 'Great Value',
  },
  {
    name: 'Sakura Boutique Hotel', city: 'Tokyo', country: 'Japan',
    img: 'https://images.pexels.com/photos/3688261/pexels-photo-3688261.jpeg?auto=compress&cs=tinysrgb&w=800',
    price: 145, rating: 9.0, reviews: 3310,
    amenities: ['Central Location', 'Wi-Fi', 'Family Room', 'Breakfast'],
    badge: 'Trending',
  },
  {
    name: 'Emerald Sands Villa', city: 'Bali', country: 'Indonesia',
    img: 'https://images.pexels.com/photos/34790496/pexels-photo-34790496.jpeg?auto=compress&cs=tinysrgb&w=800',
    price: 205, rating: 9.3, reviews: 1477,
    amenities: ['Private Pool', 'Villa', 'Spa', 'Breakfast'],
    badge: 'Romantic',
  },
];

const offers = [
  {
    tag: 'Flash Sale • 40% OFF',
    title: 'Early Summer Escapes',
    desc: 'Book beachfront stays before June and save up to 40% at 500+ top-rated resorts.',
    img: 'https://images.pexels.com/photos/29766360/pexels-photo-29766360.jpeg?auto=compress&cs=tinysrgb&w=900',
    btn: 'Grab the deal',
  },
  {
    tag: 'Members Only',
    title: 'Book + Save Extra 15%',
    desc: 'Sign up to StayEase Pro and unlock exclusive member prices on every booking.',
    img: 'https://images.pexels.com/photos/5577693/pexels-photo-5577693.jpeg?auto=compress&cs=tinysrgb&w=900',
    btn: 'Join for free',
  },
];

const features = [
  { icon: ShieldCheck, title: 'Secure Booking', desc: '256-bit encryption & bank-grade payment protection on every reservation.' },
  { icon: Wallet, title: 'Best Price Promise', desc: 'Found it cheaper? We refund the difference — guaranteed within 24 hours.' },
  { icon: Headphones, title: '24/7 Concierge', desc: 'Real humans on the phone & chat, any time zone, any language. Always.' },
  { icon: Bell, title: 'Free Cancellation', desc: 'Flexible plans on 1.4M+ properties with zero-fee cancellation windows.' },
  { icon: Ticket, title: 'Instant Vouchers', desc: 'Your e-confirmation arrives in seconds — no waiting, no paper.' },
  { icon: Banknote, title: 'Earn Rewards', desc: 'Collect StayEase Points on every night and redeem them for free stays.' },
  { icon: Globe, title: '190+ Countries', desc: 'From city hotels to private islands — book anywhere in the world.' },
  { icon: Sparkles, title: 'Curated Picks', desc: 'Handpicked, inspected and verified stays so you never book a surprise.' },
];

const testimonials = [
  {
    text: 'Booking with StayEase felt effortless. The trip planner mapped our whole Maldives escape in minutes and the price beat every other site.',
    name: 'Sofia Martinez', role: 'Travel Blogger', initials: 'SM',
  },
  {
    text: 'I travel 20+ weeks a year for work. The guest filters, instant confirmation and reward points make this my only booking app now.',
    name: 'James Carter', role: 'Consultant', initials: 'JC',
  },
  {
    text: 'The free cancellation saved us when our plans changed last minute. Their support team fixed everything within one call. Exceptional.',
    name: 'Amelia Wong', role: 'Family Traveler', initials: 'AW',
  },
];

const footerLinks = {
  company: ['About Us', 'Careers', 'Press & Media', 'Partner Program', 'Sustainability'],
  products: ['Hotels & Resorts', 'Villas & Apartments', 'Flight + Hotel', 'Group Booking', 'StayEase Business'],
  help: ['Help Center', 'Contact Support', 'Cancellation Policy', 'Privacy Policy', 'Terms & Conditions'],
};

/* ============ Helpers ============ */
const MONTHS = ['January', 'February', 'March', 'April', 'May', 'June', 'July', 'August', 'September', 'October', 'November', 'December'];
const DOW = ['Su', 'Mo', 'Tu', 'We', 'Th', 'Fr', 'Sa'];

function formatDate(d) {
  if (!d) return 'Add date';
  return d.toLocaleDateString('en-US', { day: 'numeric', month: 'short' });
}
function diffDays(a, b) {
  if (!a || !b) return 0;
  return Math.round((b - a) / 86400000);
}

/* Small month calendar of a given offset from current month */
function MonthGrid({ offset, selected, setSelected }) {
  const now = new Date();
  const base = new Date(now.getFullYear(), now.getMonth() + offset, 1);
  const year = base.getFullYear();
  const month = base.getMonth();
  const firstDay = new Date(year, month, 1).getDay();
  const daysInMonth = new Date(year, month + 1, 0).getDate();
  const today = new Date();
  today.setHours(0, 0, 0, 0);

  const cells = [...Array(firstDay).fill(null), ...Array.from({ length: daysInMonth }, (_, i) => new Date(year, month, i + 1))];

  return (
    <div>
      <div className="cal-title">{MONTHS[month]} {year}</div>
      <div className="cal-grid">
        {DOW.map((d, i) => <div key={i} className="dow">{d}</div>)}
        {cells.map((d, i) => {
          if (!d) return <div key={i} />;
          const disabled = d < today;
          const cls = [
            'cal-day',
            disabled ? 'disabled' : '',
            selected.includes(d) ? 'selected' : '',
          ].join(' ').trim();
          return (
            <div
              key={i}
              className={cls}
              onClick={() => !disabled && setSelected(d)}
            >{d.getDate()}</div>
          );
        })}
      </div>
    </div>
  );
}

/* ============ MAIN COMPONENT ============ */
export default function Home() {
  const [scrolled, setScrolled] = useState(false);
  const [openField, setOpenField] = useState(null); // 'location' | 'date' | 'guests' | null
  const [location, setLocation] = useState('New York, USA');
  const [checkIn, setCheckIn] = useState(() => { const d = new Date(); d.setDate(d.getDate() + 3); return d; });
  const [checkOut, setCheckOut] = useState(() => { const d = new Date(); d.setDate(d.getDate() + 6); return d; });
  const [adults, setAdults] = useState(2);
  const [kids, setKids] = useState(0);
  const [rooms, setRooms] = useState(1);
  const [menuOpen, setMenuOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 40);
    window.addEventListener('scroll', onScroll);
    onScroll();
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  /* Close dropdowns when clicking outside */
  useEffect(() => {
    const handler = (e) => {
      if (!e.target.closest('.search-field')) setOpenField(null);
    };
    document.addEventListener('mousedown', handler);
    return () => document.removeEventListener('mousedown', handler);
  }, []);

  const selectedDates = useMemo(() => [checkIn, checkOut].filter(Boolean), [checkIn, checkOut]);

  const handleDateClick = (d) => {
    if (!checkIn || (checkIn && checkOut)) {
      setCheckIn(d); setCheckOut(null);
    } else if (d > checkIn) {
      setCheckOut(d);
    } else {
      setCheckIn(d);
    }
  };

  const nights = diffDays(checkIn, checkOut);
  const totalGuests = adults + kids;

  return (
    <>
      {/* ================= HEADER ================= */}
      <header className={`header ${scrolled || menuOpen ? 'scrolled' : ''}`}>
        <div className="container header-inner">
          <div className="brand">
            <div className="logo-badge">
              <Building2 size={22} />
            </div>
            Stay<em>Ease</em>
          </div>

          <nav className="nav-links">
            <a href="#home" className="active">Home</a>
           
            <a href="#hotels">Hotels</a>
           
            <a href="#contact">Contact</a>
            <a href="/HotelList">Hotel List</a>
             <a href="/AdminPanel">Admin Panel</a>

          </nav>

          <div className="header-actions">
            <button className="btn-login">Sign in</button>
            <button className="btn-signup">Create Account</button>
            <button className="hamburger" onClick={() => setMenuOpen(o => !o)} aria-label="Menu">
              <svg width="22" height="22" viewBox="0 0 24 24" fill="none" stroke="#fff" strokeWidth="2">
                {menuOpen ? <path d="M6 6l12 12M6 18L18 6" /> : <path d="M3 6h18M3 12h18M3 18h18" />}
              </svg>
            </button>
          </div>
        </div>
      </header>

      {/* ================= HERO ================= */}
      <section className="hero" id="home">
        <div className="container hero-content">
          <span className="hero-eyebrow"><span className="dot" /> #1 Trusted Travel Platform — 120M+ travelers</span>
          <h1>Discover, Book & Enjoy <span className="accent">Dream Stays</span> Worldwide</h1>
          <p className="sub">
            Compare 2,400,000+ hotels, resorts and villas across 190 countries.
            Best price guaranteed, instant confirmation and free cancellation — all in one place.
          </p>

          <div className="hero-trust">
            <div className="trust-item"><span className="num">2.4M<span>+</span></span><span className="lbl">Listed Properties</span></div>
            <div className="trust-item"><span className="num">120M<span>+</span></span><span className="lbl">Happy Travelers</span></div>
            <div className="trust-item"><span className="num">4.9<span>★</span></span><span className="lbl">Average Rating</span></div>
            <div className="trust-item"><span className="num">190<span>+</span></span><span className="lbl">Countries Covered</span></div>
          </div>

          {/* ---------- SEARCH BAR ---------- */}
          <div className="search-wrap">
            <div className="search-bar">
              {/* Location */}
              <div className={`search-field ${openField === 'location' ? 'open' : ''}`}
                onClick={() => setOpenField(openField === 'location' ? null : 'location')}>
                <div className="field-icon"><MapPin size={20} /></div>
                <div className="field-body">
                  <div className="field-label">Location</div>
                  <div className="field-value">{location}</div>
                </div>
                <ChevronDown className="chev" size={18} />
                {openField === 'location' && (
                  <div className="search-dropdown" onClick={e => e.stopPropagation()}>
                    {cities.map(c => (
                      <div key={c.city} className="dropdown-city" onClick={() => { setLocation(`${c.city}, ${c.country}`); setOpenField(null); }}>
                        <div className="flag"><img src={`https://images.pexels.com/photos/${c.city === 'Paris' ? 30379456 : c.city === 'Dubai' ? 19664340 : c.city === 'Tokyo' ? 35072449 : c.city === 'Bali' ? 32314301 : c.city === 'Maldives' ? 3293192 : c.city === 'New York' ? 28411366 : c.city === 'London' ? 2725675 : 37911732}/pexels-photo-${c.city === 'Paris' ? 30379456 : c.city === 'Dubai' ? 19664340 : c.city === 'Tokyo' ? 35072449 : c.city === 'Bali' ? 32314301 : c.city === 'Maldives' ? 3293192 : c.city === 'New York' ? 28411366 : c.city === 'London' ? 2725675 : 37911732}.jpeg?auto=compress&cs=tinysrgb&w=100`} alt="" /></div>
                        <div>
                          <div className="cname">{c.city}</div>
                          <div className="cinfo">{c.country}</div>
                        </div>
                      </div>
                    ))}
                  </div>
                )}
              </div>

              {/* Dates */}
              <div className={`search-field ${openField === 'date' ? 'open' : ''}`}
                onClick={() => setOpenField(openField === 'date' ? null : 'date')}>
                <div className="field-icon"><CalendarDays size={20} /></div>
                <div className="field-body">
                  <div className="field-label">Check-in — Check-out</div>
                  <div className="field-value">{formatDate(checkIn)} {checkOut && `→ ${formatDate(checkOut)}`} {nights > 0 && ` · ${nights}n`}</div>
                </div>
                <ChevronDown className="chev" size={18} />
                {openField === 'date' && (
                  <div className="date-pop" onClick={e => e.stopPropagation()}>
                    <div className="date-months">
                      <MonthGrid offset={0} selected={selectedDates} setSelected={handleDateClick} />
                      <MonthGrid offset={1} selected={selectedDates} setSelected={handleDateClick} />
                    </div>
                    <div className="cal-foot">
                      <span>Add your travel dates for exact pricing</span>
                      <button style={{ color: 'var(--blue)', fontWeight: 700 }}
                        onClick={() => setOpenField(null)}>Apply ✓</button>
                    </div>
                  </div>
                )}
              </div>

              {/* Guests */}
              <div className={`search-field ${openField === 'guests' ? 'open' : ''}`}
                onClick={() => setOpenField(openField === 'guests' ? null : 'guests')}>
                <div className="field-icon"><Users size={20} /></div>
                <div className="field-body">
                  <div className="field-label">Guests & Rooms</div>
                  <div className="field-value">{totalGuests} {totalGuests === 1 ? 'Guest' : 'Guests'} · {rooms} Room{rooms > 1 ? 's' : ''}</div>
                </div>
                <ChevronDown className="chev" size={18} />
                {openField === 'guests' && (
                  <div className="guests-pop" onClick={e => e.stopPropagation()}>
                    <div className="guests-row">
                      <div className="guests-info"><div className="g-title">Adults</div><div className="g-sub">Age 13+</div></div>
                      <div className="stepper">
                        <button disabled={adults <= 1} onClick={() => setAdults(a => a - 1)}>−</button>
                        <span className="val">{adults}</span>
                        <button onClick={() => setAdults(a => a + 1)}>+</button>
                      </div>
                    </div>
                    <div className="guests-row">
                      <div className="guests-info"><div className="g-title">Children</div><div className="g-sub">Age 0–12</div></div>
                      <div className="stepper">
                        <button disabled={kids <= 0} onClick={() => setKids(k => k - 1)}>−</button>
                        <span className="val">{kids}</span>
                        <button onClick={() => setKids(k => k + 1)}>+</button>
                      </div>
                    </div>
                    <div className="guests-row">
                      <div className="guests-info"><div className="g-title">Rooms</div><div className="g-sub">Max 8 rooms</div></div>
                      <div className="stepper">
                        <button disabled={rooms <= 1} onClick={() => setRooms(r => r - 1)}>−</button>
                        <span className="val">{rooms}</span>
                        <button disabled={rooms >= 8} onClick={() => setRooms(r => r + 1)}>+</button>
                      </div>
                    </div>
                  </div>
                )}
              </div>

              {/* Search button */}
              <button className="search-btn" onClick={() => { setOpenField(null); alert(`Searching ${location} · ${totalGuests} guest(s) · ${nights} night(s)`); }}>
                <Search size={20} /> Search
              </button>
            </div>
          </div>
        </div>

        <div className="scroll-hint">
          <div className="mouse" />
          Scroll to explore
        </div>
      </section>

      {/* ================= DESTINATIONS ================= */}
      <section className="section" id="destinations">
        <div className="container">
          <div className="section-head">
            <span className="section-tag">Explore the World</span>
            <h2 className="section-title">Popular Destinations <span className="hl">By Locale</span></h2>
            <p className="section-desc">Handpicked cities and islands loved by our travelers, with real-time hotel availability and exclusive local deals.</p>
          </div>

          <div className="dest-grid">
            {destinations.map((d, i) => (
              <div key={d.city} className={`dest-card ${d.tall ? 'tall' : ''}`} style={{ gridColumn: i === 4 ? 'span 2' : 'auto' }}>
                <img src={d.img} alt={d.city} />
                <div className="overlay" />
                <div className="info">
                  <div className="city">
                    {d.city}
                    <span className="arrow"><ArrowUpRight size={18} /></span>
                  </div>
                  <div className="country">{d.country}</div>
                  <div className="meta">
                    <span><b>{d.hotels}</b> stays</span>
                    <span><b>{d.deals}</b> deals</span>
                    <span>from <b>${d.start}</b></span>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ================= TRIP PLANNER ================= */}
      <section className="trip-zone" id="planner">
        <div className="container">
          <div className="section-head">
            <span className="section-tag" style={{ background: 'rgba(255,184,77,0.15)', color: 'var(--gold)' }}>Plan Smarter</span>
            <h2 className="section-title">Quick & Easy <span style={{ color: 'var(--gold-2)' }}>Trip Planner</span></h2>
            <p className="section-desc">Three effortless steps between "I need a holiday" and the perfect doorstep. No stress, no hidden fees.</p>
          </div>

          <div className="trip-steps">
            {steps.map((s, i) => (
              <div className="step-card" key={i}>
                <div className="step-img">
                  <img src={s.img} alt={s.title} />
                  <div className="step-num">0{i + 1}</div>
                </div>
                <div className="step-body">
                  <h3>{s.title}</h3>
                  <p>{s.desc}</p>
                  <div className="step-dur"><Clock size={15} /> {s.dur}</div>
                  <div className="step-link">Learn more <ArrowRight size={15} /></div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ================= FEATURED HOTELS ================= */}
      <section className="section" id="hotels">
        <div className="container">
          <div className="section-head">
            <span className="section-tag">Top Rated</span>
            <h2 className="section-title">Trending <span className="hl">Stays for You</span></h2>
            <p className="section-desc">Verified properties with exceptional guest reviews, location scores and unbeatable member rates.</p>
          </div>

          <div className="hotels-grid">
            {hotels.map((h) => (
              <div className="hotel-card" key={h.name}>
                <div className="hotel-img">
                  <img src={h.img} alt={h.name} />
                  <span className="hotel-badge">{h.badge}</span>
                  <div className="hotel-fav"><HeartIcon /></div>
                </div>
                <div className="hotel-body">
                  <div className="hotel-top">
                    <div>
                      <div className="hotel-name">{h.name}</div>
                      <div className="hotel-loc"><MapPin size={13} /> {h.city}, {h.country}</div>
                    </div>
                    <div className="hotel-score">
                      <span className="score">{h.rating}</span>
                      <span className="reviews">{h.reviews} reviews</span>
                    </div>
                  </div>
                  <div className="hotel-amenities">
                    {h.amenities.map(a => <span className="amen" key={a}>{a}</span>)}
                  </div>
                  <div className="hotel-foot">
                    <div className="hotel-price">
                      <div className="from">per night</div>
                      <div className="price">${h.price} <small>USD</small></div>
                    </div>
                    <button className="btn-ghost">View Deal</button>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ================= OFFERS ================= */}
      <section className="section" id="offers" style={{ paddingTop: 0 }}>
        <div className="container">
          <div className="section-head">
            <span className="section-tag">Limited Time</span>
            <h2 className="section-title">Deals & <span className="hl">Special Offers</span></h2>
            <p className="section-desc">Save big with seasonal promotions, member-exclusive rates and flash deals that update daily.</p>
          </div>

          <div className="offers-grid">
            {offers.map((o, i) => (
              <div className="offer-card" key={i}>
                <img src={o.img} alt={o.title} />
                <div className="ove" />
                <div className="odiv">
                  <span className="otag">{o.tag}</span>
                  <h3>{o.title}</h3>
                  <p>{o.desc}</p>
                  <button className="obtn">{o.btn}</button>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ================= WHY US ================= */}
      <section className="section" style={{ paddingTop: 0 }}>
        <div className="container">
          <div className="section-head">
            <span className="section-tag">Why StayEase</span>
            <h2 className="section-title">Book With <span className="hl">Total Confidence</span></h2>
            <p className="section-desc">From security to savings, every booking comes loaded with benefits designed to protect you.</p>
          </div>

          <div className="why-us">
            <div className="features-grid">
              {features.map((f, i) => (
                <div className="feature" key={i}>
                  <div className="ficon"><f.icon size={30} /></div>
                  <h4>{f.title}</h4>
                  <p>{f.desc}</p>
                </div>
              ))}
            </div>
          </div>
        </div>
      </section>

      {/* ================= TESTIMONIALS ================= */}
      <section className="section" style={{ paddingTop: 0 }}>
        <div className="container">
          <div className="section-head">
            <span className="section-tag">Loved Worldwide</span>
            <h2 className="section-title">What Our <span className="hl">Travelers Say</span></h2>
            <p className="section-desc">Over 120 million travelers trust us with their journeys every single year.</p>
          </div>

          <div className="testi-grid">
            {testimonials.map((t, i) => (
              <div className="testi-card" key={i}>
                <span className="quote-mark"><Quote /></span>
                <div className="testi-stars">★★★★★</div>
                <p className="testi-text">"{t.text}"</p>
                <div className="testi-user">
                  <div className="avatar">{t.initials}</div>
                  <div>
                    <div className="uname">{t.name}</div>
                    <div className="urole">{t.role}</div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ================= APP CTA ================= */}
      <section className="section" style={{ paddingTop: 0 }}>
        <div className="container">
          <div className="cta-zone">
            <div>
              <span className="section-tag" style={{ background: 'rgba(255,255,255,0.2)', color: '#fff' }}>Take us everywhere</span>
              <h2>Your Entire Trip, In Your Pocket</h2>
              <p>Book, manage, check-in and get live concierge support from the StayEase app. Download now and unlock an extra 10% off your first booking.</p>
              <div className="cta-badges">
                <a className="store-badge">
                  <svg width="24" height="24" viewBox="0 0 24 24" fill="#fff"><path d="M17.05 20.28c-.98.95-2.05.8-3.08.35-1.09-.46-2.09-.48-3.24 0-1.44.62-2.2.44-3.06-.35C2.79 15.25 3.51 7.59 9.05 7.31c1.35.07 2.29.74 3.08.8 1.18-.24 2.31-.93 3.57-.84 1.51.12 2.65.72 3.4 1.8-3.12 1.87-2.38 5.98.48 7.13-.57 1.5-1.31 2.99-2.54 4.09l.01-.01zM12.03 7.25c-.15-2.23 1.66-4.07 3.74-4.25.29 2.58-2.34 4.5-3.74 4.25z"/></svg>
                  <div><div className="st-small">Download on the</div><div className="st-big">App Store</div></div>
                </a>
                <a className="store-badge">
                  <svg width="22" height="22" viewBox="0 0 24 24" fill="#fff"><path d="M3 20.5v-17c0-.59.34-1.11.84-1.35L13.69 12 3.84 21.85c-.5-.25-.84-.76-.84-1.35zm13.81-5.38L6.05 21.34l8.49-8.49 2.27 2.27zm3.35-4.31c.34.27.59.69.61 1.19s-.24.94-.6 1.2l-2.27 1.31-2.5-2.5 2.5-2.5 2.26 1.3zM6.05 2.66l10.76 6.22-2.27 2.27L6.05 2.66z"/></svg>
                  <div><div className="st-small">Get it on</div><div className="st-big">Google Play</div></div>
                </a>
              </div>
            </div>
            <div className="cta-mock">
              <div className="phone">
                <div className="phone-screen">
                  <img src="https://images.pexels.com/photos/23696832/pexels-photo-23696832.jpeg?auto=compress&cs=tinysrgb&w=500" alt="App" />
                </div>
              </div>
            </div>
          </div>
        </div>
      </section>

      {/* ================= NEWSLETTER ================= */}
      <section className="section" style={{ paddingTop: 0, paddingBottom: 70 }}>
        <div className="container">
          <div className="newsletter">
            <div>
              <h3>Get Travel Deals First ✈️</h3>
              <p>Subscribe for exclusive offers, member rates and week-ahead price alerts.</p>
            </div>
            <form className="news-form" onSubmit={(e) => { e.preventDefault(); alert('Subscribed! Watch your inbox for deals.'); }}>
              <input type="email" placeholder="Enter your email address" required />
              <button type="submit">Subscribe</button>
            </form>
          </div>
        </div>
      </section>

      {/* ================= FOOTER ================= */}
      <footer className="footer" id="contact">
        <div className="container">
          <div className="footer-grid">
            <div>
              <div className="brand">
                <div className="logo-badge"><Building2 size={22} /></div>
                Stay<em>Ease</em>
              </div>
              <p className="footer-about">
                StayEase is the world's leading travel booking platform. We connect travelers
                to 2.4M+ verified properties with best-price guarantees, instant confirmation and 24/7 human support.
              </p>
              <div className="footer-social">
                <a href="#" aria-label="Facebook"><svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M13 10h3l.5-3H13V5.5c0-.9.3-1.5 1.6-1.5H17V1.2C16.6 1.1 15.6 1 14.6 1 12 1 10.3 2.5 10.3 5.2V7H7v3h3.3v9H13v-9z"/></svg></a>
                <a href="#" aria-label="Instagram"><svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2"><rect x="2" y="2" width="20" height="20" rx="5"/><circle cx="12" cy="12" r="4"/><circle cx="17.5" cy="6.5" r="1" fill="currentColor" stroke="none"/></svg></a>
                <a href="#" aria-label="Twitter"><svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M22 5.9c-.7.3-1.5.5-2.3.6.8-.5 1.4-1.3 1.7-2.2-.8.5-1.7.8-2.6 1a4 4 0 0 0-6.9 3.6A11.4 11.4 0 0 1 3.8 4.6a4 4 0 0 0 1.2 5.3c-.6 0-1.2-.2-1.7-.5v.1a4 4 0 0 0 3.2 3.9c-.6.2-1.2.2-1.8.1a4 4 0 0 0 3.7 2.8A8 8 0 0 1 2 18.6a11.3 11.3 0 0 0 6.1 1.8c7.4 0 11.4-6.1 11.4-11.4v-.5c.8-.6 1.5-1.3 2-2.2z"/></svg></a>
                <a href="#" aria-label="YouTube"><svg width="18" height="18" viewBox="0 0 24 24" fill="currentColor"><path d="M23 7.5s-.2-1.6-.9-2.3c-.9-.9-1.9-.9-2.4-1C16.6 4 12 4 12 4s-4.6 0-7.7.2c-.5.1-1.5.1-2.4 1-.7.7-.9 2.3-.9 2.3S.8 9.4.8 11.3v1.4c0 1.9.2 3.8.2 3.8s.2 1.6.9 2.3c.9.9 2 .8 2.5.9 1.8.2 7.6.2 7.6.2s4.6 0 7.7-.2c.5-.1 1.5-.1 2.4-1 .7-.7.9-2.3.9-2.3s.2-1.9.2-3.8v-1.4c0-1.9-.2-3.8-.2-3.8zM9.8 15.1V8.5l6.2 3.3-6.2 3.3z"/></svg></a>
              </div>
            </div>

            <div>
              <h5>Company</h5>
              <ul className="footer-links">
                {footerLinks.company.map(l => <li key={l}><a href="#">{l}</a></li>)}
              </ul>
            </div>

            <div>
              <h5>Explore</h5>
              <ul className="footer-links">
                {footerLinks.products.map(l => <li key={l}><a href="#">{l}</a></li>)}
              </ul>
            </div>

            <div>
              <h5>Get in Touch</h5>
              <ul className="footer-contact">
                <li><Phone size={16} /> +1 (800) 555-0199</li>
                <li><Mail size={16} /> support@stayease.com</li>
                <li><Pin size={16} /> 100 Harbor Point, Suite 500<br />New York, NY 10007</li>
              </ul>
            </div>
          </div>

          <div className="footer-bottom">
            <span>© {new Date().getFullYear()} StayEase Travel Ltd. All rights reserved.</span>
            <div className="pay">
              We accept
              <span className="pay-chip">VISA</span>
              <span className="pay-chip">Mastercard</span>
              <span className="pay-chip">Amex</span>
              <span className="pay-chip">PayPal</span>
            </div>
          </div>
        </div>
      </footer>
    </>
  );
}

/* Heart icon helper */
function HeartIcon() {
  return (
    <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2">
      <path d="M20.84 4.61a5.5 5.5 0 0 0-7.78 0L12 5.67l-1.06-1.06a5.5 5.5 0 1 0-7.78 7.78l1.06 1.06L12 21.23l7.78-7.78 1.06-1.06a5.5 5.5 0 0 0 0-7.78z" />
    </svg>
  );
}
