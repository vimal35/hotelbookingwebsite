import React, { useEffect, useMemo, useState } from 'react';
import { Link, useParams } from 'react-router-dom';
import {
  MapPin, Leaf, ShieldCheck, Banknote, Check, ChevronRight, ChevronLeft, X, Sparkles,
  BedDouble, Users, Maximize, ThumbsUp, CalendarDays, Clock, ArrowLeft, Share2,
  Heart, ArrowRight, Baby, CreditCard, Map as MapIcon, LayoutGrid, Info, Wifi, Dog,
} from 'lucide-react';
import { HOTELS, Stars, ratingLabel, AMENITY_ICONS } from './HotelList';
import './HotelDetailPage.css';

const DAY = 86400000;
const fmt = (d) => new Date(d).toISOString().slice(0, 10);

export default function HotelDetailPage() {
  const { id } = useParams();
  const hotel = HOTELS.find((h) => h.id === id);

  const todayStr = fmt(Date.now());
  const [checkIn, setCheckIn] = useState(fmt(Date.now() + DAY));
  const [checkOut, setCheckOut] = useState(fmt(Date.now() + 3 * DAY));
  const [adults, setAdults] = useState(2);
  const [rooms, setRooms] = useState(1);
  const [wish, setWish] = useState(false);
  const [lightbox, setLightbox] = useState(false);
  const [photo, setPhoto] = useState(0);
  const [confirm, setConfirm] = useState(null);
  const [done, setDone] = useState(false);
  const [copied, setCopied] = useState(false);

  const nights = Math.max(1, Math.round((new Date(checkOut) - new Date(checkIn)) / DAY) || 1);

  const similar = useMemo(() => {
    if (!hotel) return [];
    return HOTELS.filter((h) => h.id !== hotel.id && (h.type === hotel.type || h.area === hotel.area))
      .sort((a, b) => b.rating - a.rating)
      .slice(0, 3);
  }, [hotel]);

  useEffect(() => {
    window.scrollTo(0, 0);
  }, [id]);

  useEffect(() => {
    try {
      setWish((JSON.parse(localStorage.getItem('tn_wishlist')) || []).includes(id));
    } catch { /* ignore */ }
  }, [id]);

  useEffect(() => {
    document.body.style.overflow = lightbox || confirm ? 'hidden' : '';
    return () => { document.body.style.overflow = ''; };
  }, [lightbox, confirm]);

  useEffect(() => {
    if (!lightbox) return undefined;
    const onKey = (e) => {
      if (e.key === 'Escape') setLightbox(false);
      if (e.key === 'ArrowRight') setPhoto((p) => (p + 1) % hotel.gallery.length);
      if (e.key === 'ArrowLeft') setPhoto((p) => (p - 1 + hotel.gallery.length) % hotel.gallery.length);
    };
    window.addEventListener('keydown', onKey);
    return () => window.removeEventListener('keydown', onKey);
  }, [lightbox, hotel]);

  if (!hotel) {
    return (
      <div className="dp-app">
        <header className="dp-header">
          <div className="dp-header-inner">
            <Link to="/" className="dp-brand"><span className="dp-brand-mark">TN</span> TravelNest</Link>
          </div>
        </header>
        <div className="dp-404">
          <h1>Property not found</h1>
          <p>The stay you are looking for is no longer available.</p>
          <Link to="/" className="dp-404-btn">Back to Dubai hotels</Link>
        </div>
      </div>
    );
  }

  const toggleWish = () => {
    setWish((w) => {
      const nw = !w;
      try {
        const list = JSON.parse(localStorage.getItem('tn_wishlist')) || [];
        const out = nw ? [...new Set([...list, id])] : list.filter((x) => x !== id);
        localStorage.setItem('tn_wishlist', JSON.stringify(out));
      } catch { /* ignore */ }
      return nw;
    });
  };

  const openLightbox = (i) => { setPhoto(i); setLightbox(true); };

  const share = async () => {
    try {
      await navigator.clipboard.writeText(window.location.href);
      setCopied(true);
      setTimeout(() => setCopied(false), 1800);
    } catch { /* ignore */ }
  };

  const scrollToRooms = () => {
    const el = document.getElementById('dp-rooms');
    if (el) el.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  const reserve = (roomName) => { setConfirm(roomName); setDone(false); };

  const taxesFor = (p) => Math.round(p * 0.12);
  const widgetTotal = (hotel.price + hotel.taxes) * nights;

  return (
    <div className="dp-app">
      

      <nav className="dp-subnav">
        <div className="dp-subnav-inner">
          <Link to="/" className="dp-back"><ArrowLeft size={15} /> <span>All Dubai stays</span></Link>
          <div className="dp-subnav-links">
            <a href="#dp-overview">Overview</a>
            <a href="#dp-rooms">Rooms</a>
            <a href="#dp-amenities">Facilities</a>
            <a href="#dp-reviews">Reviews</a>
            <a href="#dp-location">Location</a>
            <a href="#dp-policies">Policies</a>
          </div>
          <div className="dp-subnav-cta">
            <span>from <b>${hotel.price.toLocaleString()}</b> / night</span>
            <button onClick={scrollToRooms}>View rooms</button>
          </div>
        </div>
      </nav>

      <main className="dp-main">
        {/* ------------------------------ gallery ------------------------------ */}
        <div className="dp-gallery">
          <button className="dp-g-main" onClick={() => openLightbox(0)}>
            <img src={hotel.gallery[0]} alt={hotel.name} />
            <span className="dp-g-all"><LayoutGrid size={14} /> View all photos</span>
          </button>
          <div className="dp-g-side">
            {hotel.gallery.slice(1, 5).map((g, i) => (
              <button key={i} onClick={() => openLightbox(i + 1)}>
                <img src={g} alt={`${hotel.name} photo ${i + 2}`} loading="lazy" />
              </button>
            ))}
          </div>
        </div>

        {/* ------------------------------ title bar ---------------------------- */}
        <div className="dp-titlebar">
          <div className="dp-title-left">
            <div className="dp-crumb">
              <Link to="/">Dubai</Link> <ChevronRight size={12} /> <span>{hotel.area}</span>
            </div>
            <h1>{hotel.name}</h1>
            <div className="dp-subline">
              <Stars n={hotel.stars} size={15} />
              <span className="dp-ptype">{hotel.type}</span>
              <span className="dp-addr"><MapPin size={14} /> {hotel.address}</span>
            </div>
            <div className="dp-usps">
              {hotel.sustainable && <span className="dp-usp green"><Leaf size={13} /> Sustainable property</span>}
              {hotel.freeCancel && <span className="dp-usp green"><ShieldCheck size={13} /> Free cancellation</span>}
              {hotel.noPrepay && <span className="dp-usp"><Banknote size={13} /> No prepayment needed</span>}
              {hotel.breakfast && <span className="dp-usp"><Sparkles size={13} /> Breakfast included</span>}
            </div>
          </div>
          <div className="dp-title-rating">
            <span className="dp-score">{hotel.rating.toFixed(1)}</span>
            <div className="dp-score-txt">
              <b>{ratingLabel(hotel.rating)}</b>
              <span>{hotel.reviews.toLocaleString()} verified reviews</span>
            </div>
          </div>
        </div>

        {/* ------------------------------- layout ------------------------------ */}
        <div className="dp-layout">
          <div className="dp-content">
            {/* overview */}
            <section id="dp-overview" className="dp-sec">
              <h2>Property overview</h2>
              <p className="dp-desc">{hotel.desc}</p>
              <div className="dp-highlights">
                {hotel.highlights.map((hi) => (
                  <div key={hi}><Sparkles size={14} /> <span>{hi}</span></div>
                ))}
              </div>
              <div className="dp-facts">
                <div><CalendarDays size={17} /><b>Check-in</b><span>{hotel.checkIn}</span></div>
                <div><CalendarDays size={17} /><b>Check-out</b><span>{hotel.checkOut}</span></div>
                <div><MapPin size={17} /><b>Distance from centre</b><span>{hotel.distance} km</span></div>
                <div><Wifi size={17} /><b>High-speed WiFi</b><span>Free throughout</span></div>
              </div>
            </section>

            {/* rooms */}
            <section id="dp-rooms" className="dp-sec">
              <h2>Choose your room</h2>
              <p className="dp-sec-sub">
                Prices shown for {nights} night{nights > 1 ? 's' : ''}, {adults} adult{adults > 1 ? 's' : ''}, {rooms} room{rooms > 1 ? 's' : ''}. Taxes calculated at checkout.
              </p>
              <div className="dp-rooms">
                {hotel.rooms.map((r) => (
                  <div className="dp-room" key={r.name}>
                    <div className="dp-room-media">
                      <img src={r.img} alt={r.name} loading="lazy" />
                    </div>
                    <div className="dp-room-info">
                      <h3>{r.name}</h3>
                      <div className="dp-room-meta">
                        <span><BedDouble size={15} /> {r.bed}</span>
                        <span><Users size={15} /> Sleeps {r.guests}</span>
                        <span><Maximize size={15} /> {r.size} m&sup2;</span>
                      </div>
                      <ul className="dp-room-benefits">
                        {r.benefits.map((b) => (
                          <li key={b} className={b.startsWith('Free') ? 'ok' : ''}>
                            {b.startsWith('Free') ? <ShieldCheck size={13} /> : <Info size={13} />} {b}
                          </li>
                        ))}
                      </ul>
                    </div>
                    <div className="dp-room-price">
                      <span className="dp-room-p">${r.price.toLocaleString()} <em>/ night</em></span>
                      <span className="dp-room-tax">+ ${taxesFor(r.price)} taxes &amp; fees</span>
                      <span className="dp-room-total">${((r.price + taxesFor(r.price)) * nights).toLocaleString()} total</span>
                      <button onClick={() => reserve(r.name)}>Reserve</button>
                    </div>
                  </div>
                ))}
              </div>
            </section>

            {/* amenities */}
            <section id="dp-amenities" className="dp-sec">
              <h2>Facilities &amp; amenities</h2>
              <div className="dp-amen-grid">
                {hotel.amenities.map((a) => {
                  const Ic = AMENITY_ICONS[a] || Check;
                  return <div key={a}><Ic size={16} /> {a}</div>;
                })}
              </div>
            </section>

            {/* reviews */}
            <section id="dp-reviews" className="dp-sec">
              <h2>Guest reviews</h2>
              <div className="dp-reviews-top">
                <div className="dp-score-big">
                  <span className="dp-score-big-num">{hotel.rating.toFixed(1)}</span>
                  <b>{ratingLabel(hotel.rating)}</b>
                  <span className="dp-score-big-rev">{hotel.reviews.toLocaleString()} reviews</span>
                </div>
                <div className="dp-cats">
                  {Object.entries(hotel.cats).map(([k, v]) => (
                    <div className="dp-cat" key={k}>
                      <span className="dp-cat-name">{k}</span>
                      <div className="dp-cat-bar"><i style={{ width: `${v * 10}%` }} /></div>
                      <b>{v.toFixed(1)}</b>
                    </div>
                  ))}
                </div>
              </div>
              <div className="dp-review-list">
                {hotel.guestReviews.map((r, i) => (
                  <div className="dp-review" key={i}>
                    <div className="dp-review-head">
                      <span className="dp-avatar">{r.name[0]}</span>
                      <div className="dp-review-who">
                        <b>{r.name}</b>
                        <span>{r.country}</span>
                      </div>
                      <span className="dp-review-score">{r.score.toFixed(1)}</span>
                    </div>
                    <div className="dp-review-title"><ThumbsUp size={13} /> {r.title}</div>
                    <p>{r.comment}</p>
                    <span className="dp-review-date">{r.date} &middot; Verified stay</span>
                  </div>
                ))}
              </div>
            </section>

            {/* location */}
            <section id="dp-location" className="dp-sec">
              <h2>Location &amp; surroundings</h2>
              <div className="dp-loc">
                <div className="dp-loc-map">
                  <div className="dp-loc-water" />
                  <div className="dp-loc-road a" />
                  <div className="dp-loc-road b" />
                  <span className="dp-loc-label" style={{ top: '12%', left: '10%' }}>DOWNTOWN</span>
                  <span className="dp-loc-label" style={{ bottom: '14%', right: '12%' }}>CREEK</span>
                  <span className="dp-loc-pin"><MapIcon size={22} /></span>
                  <span className="dp-loc-name">{hotel.name}</span>
                </div>
                <ul className="dp-landmarks">
                  {hotel.landmarks.map((l) => (
                    <li key={l.name}><MapPin size={14} /> <span>{l.name}</span> <b>{l.d}</b></li>
                  ))}
                  <li><MapPin size={14} /> <span>Dubai city centre</span> <b>{hotel.distance} km</b></li>
                  <li><MapPin size={14} /> <span>Dubai Intl. Airport</span> <b>{(hotel.distance + 4.2).toFixed(1)} km</b></li>
                </ul>
              </div>
            </section>

            {/* policies */}
            <section id="dp-policies" className="dp-sec">
              <h2>House rules</h2>
              <div className="dp-pol-grid">
                <div><Clock size={16} /><b>Check-in</b><span>{hotel.checkIn}</span></div>
                <div><Clock size={16} /><b>Check-out</b><span>{hotel.checkOut}</span></div>
                <div><ShieldCheck size={16} /><b>Cancellation</b><span>{hotel.freeCancel ? 'Free cancellation before 24 hours on most rooms' : 'Varies by room — see each option'}</span></div>
                <div><Baby size={16} /><b>Children</b><span>Children of any age are welcome. Cots and extra beds on request.</span></div>
                <div><Dog size={16} /><b>Pets</b><span>{hotel.amenities.includes('Pet friendly') ? 'Pets stay free of charge on request' : 'Pets are not allowed'}</span></div>
                <div><CreditCard size={16} /><b>Payment</b><span>Cards, digital wallets and cash accepted at the property</span></div>
              </div>
            </section>
          </div>

          {/* ------------------------------ booking widget ------------------------------ */}
          <aside className="dp-widget">
            <div className="dp-widget-card">
              <div className="dp-widget-head">
                <span className="dp-widget-price"><em>from</em> <b>${hotel.price.toLocaleString()}</b> <em>/ night</em></span>
                <span className="dp-widget-rating">
                  <span className="dp-widget-score">{hotel.rating.toFixed(1)}</span>
                  {ratingLabel(hotel.rating)} &middot; {hotel.reviews.toLocaleString()} reviews
                </span>
              </div>

              <div className="dp-widget-dates">
                <label>
                  <em>Check-in</em>
                  <input type="date" min={todayStr} value={checkIn}
                    onChange={(e) => {
                      const v = e.target.value;
                      setCheckIn(v);
                      if (new Date(checkOut) <= new Date(v)) setCheckOut(fmt(new Date(v).getTime() + DAY));
                    }} />
                </label>
                <label>
                  <em>Check-out</em>
                  <input type="date" min={fmt(new Date(checkIn).getTime() + DAY)} value={checkOut}
                    onChange={(e) => setCheckOut(e.target.value)} />
                </label>
                <label className="dp-widget-guests">
                  <em>Guests</em>
                  <span>
                    <select value={adults} onChange={(e) => setAdults(+e.target.value)}>
                      {[1, 2, 3, 4, 5, 6].map((n) => <option key={n} value={n}>{n} adult{n > 1 ? 's' : ''}</option>)}
                    </select>
                    <select value={rooms} onChange={(e) => setRooms(+e.target.value)}>
                      {[1, 2, 3, 4].map((n) => <option key={n} value={n}>{n} room{n > 1 ? 's' : ''}</option>)}
                    </select>
                  </span>
                </label>
              </div>

              <div className="dp-widget-bill">
                <div><span>${hotel.price.toLocaleString()} &times; {nights} night{nights > 1 ? 's' : ''}</span><span>${(hotel.price * nights).toLocaleString()}</span></div>
                <div><span>Taxes &amp; fees</span><span>${(hotel.taxes * nights).toLocaleString()}</span></div>
                <div className="dp-widget-total"><span>Total</span><span>${widgetTotal.toLocaleString()}</span></div>
              </div>

              <button className="dp-widget-btn" onClick={() => reserve('Best available room')}>Reserve now</button>

              <p className="dp-widget-note"><ShieldCheck size={14} /> {hotel.freeCancel ? 'Free cancellation before 24 hours' : 'Non-refundable rate'}</p>
              <p className="dp-widget-note"><Banknote size={14} /> {hotel.payLater ? 'Pay at the property — no card needed today' : 'Secure online prepayment'}</p>
              <p className="dp-widget-note"><Info size={14} /> You will not be charged until after your stay</p>
            </div>
            <div className="dp-widget-stamp">
              <Sparkles size={14} /> <span><b>{Math.floor(hotel.reviews / 40)}</b> travellers looked at this property in the last hour</span>
            </div>
          </aside>
        </div>

        {/* ------------------------------ similar ------------------------------ */}
        <section className="dp-similar">
          <h2>Guests also considered</h2>
          <div className="dp-similar-grid">
            {similar.map((h) => (
              <Link to={`/hotel/${h.id}`} className="dp-sim-card" key={h.id}>
                <div className="dp-sim-media">
                  <img src={h.image} alt={h.name} loading="lazy" />
                </div>
                <div className="dp-sim-body">
                  <h3>{h.name}</h3>
                  <Stars n={h.stars} size={12} />
                  <span className="dp-sim-loc"><MapPin size={12} /> {h.area} &middot; {h.distance} km from centre</span>
                  <div className="dp-sim-foot">
                    <span className="dp-sim-score">{h.rating.toFixed(1)} <em>{ratingLabel(h.rating)}</em></span>
                    <span className="dp-sim-price">${h.price.toLocaleString()} <em>/ night</em></span>
                  </div>
                </div>
              </Link>
            ))}
          </div>
        </section>
      </main>

      {/* ------------------------------ mobile bar ------------------------------ */}
      <div className="dp-mbar">
        <div className="dp-mbar-price">
          <b>${hotel.price.toLocaleString()}</b> / night
          <span>+ ${hotel.taxes} taxes &middot; ${widgetTotal.toLocaleString()} total</span>
        </div>
        <button onClick={scrollToRooms}>Choose a room</button>
      </div>

      {/* ------------------------------ lightbox ------------------------------ */}
      {lightbox && (
        <div className="dp-lightbox" onClick={() => setLightbox(false)}>
          <button className="dp-lb-close" aria-label="Close"><X size={20} /></button>
          <button className="dp-lb-prev" onClick={(e) => { e.stopPropagation(); setPhoto((photo - 1 + hotel.gallery.length) % hotel.gallery.length); }} aria-label="Previous">
            <ChevronLeft size={26} />
          </button>
          <img src={hotel.gallery[photo]} alt={`${hotel.name} gallery`} onClick={(e) => e.stopPropagation()} />
          <button className="dp-lb-next" onClick={(e) => { e.stopPropagation(); setPhoto((photo + 1) % hotel.gallery.length); }} aria-label="Next">
            <ChevronRight size={26} />
          </button>
          <div className="dp-lb-count" onClick={(e) => e.stopPropagation()}>{photo + 1} / {hotel.gallery.length}</div>
          <div className="dp-lb-thumbs" onClick={(e) => e.stopPropagation()}>
            {hotel.gallery.map((g, i) => (
              <button key={i} className={i === photo ? 'on' : ''} onClick={() => setPhoto(i)}>
                <img src={g} alt="" />
              </button>
            ))}
          </div>
        </div>
      )}

      {/* ------------------------------ booking modal ------------------------------ */}
      {confirm && (
        <div className="dp-modal" onClick={() => setConfirm(null)}>
          <div className="dp-modal-card" onClick={(e) => e.stopPropagation()}>
            {!done ? (
              <>
                <div className="dp-modal-head">
                  <h3>Confirm your booking</h3>
                  <button onClick={() => setConfirm(null)} aria-label="Close"><X size={18} /></button>
                </div>
                <div className="dp-modal-body">
                  <div className="dp-modal-hotel">
                    <img src={hotel.image} alt={hotel.name} />
                    <div>
                      <b>{hotel.name}</b>
                      <span>{hotel.area}, Dubai &middot; {hotel.type} &middot; {hotel.stars} stars</span>
                    </div>
                  </div>
                  <dl className="dp-modal-rows">
                    <div><dt>Room</dt><dd>{confirm}</dd></div>
                    <div><dt>Check-in</dt><dd>{checkIn}</dd></div>
                    <div><dt>Check-out</dt><dd>{checkOut}</dd></div>
                    <div><dt>Guests</dt><dd>{adults} adult{adults > 1 ? 's' : ''}, {rooms} room{rooms > 1 ? 's' : ''}</dd></div>
                    <div><dt>Stay</dt><dd>{nights} night{nights > 1 ? 's' : ''}</dd></div>
                  </dl>
                  <div className="dp-modal-total">
                    <span>Total incl. taxes</span>
                    <b>${widgetTotal.toLocaleString()}</b>
                  </div>
                </div>
                <div className="dp-modal-foot">
                  <button className="ghost" onClick={() => setConfirm(null)}>Keep browsing</button>
                  <button className="solid" onClick={() => setDone(true)}>Confirm booking</button>
                </div>
              </>
            ) : (
              <div className="dp-modal-done">
                <span className="dp-done-ic"><Check size={44} strokeWidth={2.5} /></span>
                <h3>You are booked!</h3>
                <p>{hotel.name} &middot; {confirm}</p>
                <div className="dp-done-row"><span>Check-in</span><b>{checkIn} from {hotel.checkIn.split(' ')[0]}</b></div>
                <div className="dp-done-row"><span>Check-out</span><b>{checkOut} by {hotel.checkOut.split(' – ')[1]}</b></div>
                <div className="dp-done-row"><span>Confirmation number</span><b>TN-{hotel.id.slice(0, 4).toUpperCase()}-{String(Math.abs(nights * 739 + hotel.price)).slice(0, 5)}</b></div>
                <div className="dp-modal-foot center">
                  <button className="ghost" onClick={() => setConfirm(null)}>Close</button>
                  <Link className="solid" to="/" onClick={() => setConfirm(null)}>Back to search</Link>
                </div>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
}
